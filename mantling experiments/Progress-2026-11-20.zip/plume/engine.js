/* Browser: Mantling.render(strokes, options). Node: require('./engine.js').
 * Coordinates are in the editor's 400 × 370 viewBox. All geometry is deterministic.
 * Each guide is a half-achievement, authored on the right; reflection is applied last.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.Mantling = api;
})(typeof globalThis === 'undefined' ? this : globalThis, function () {
  'use strict';
  const PI = Math.PI, TAU = 2 * PI;
  const clamp = (x, lo, hi) => Math.max(lo, Math.min(hi, x));
  const mix = (a, b, t) => a + (b - a) * t;
  const lerp = (a, b, t) => [mix(a[0], b[0], t), mix(a[1], b[1], t)];
  const dist = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1]);
  const fmt = n => Number(n.toFixed(2));
  const xy = p => fmt(p[0]) + ' ' + fmt(p[1]);
  const unit = (x,y) => { const d = Math.hypot(x,y) || 1; return [x/d,y/d]; };
  const move = (p,t,n,x,y) => [p[0]+t[0]*x+n[0]*y, p[1]+t[1]*x+n[1]*y];

  // Equal-distance sampling before corner cutting makes a slowly drawn line
  // behave like the same gesture drawn quickly.
  function measure(points) {
    const lengths = [0];
    for (let i = 1; i < points.length; i++) lengths.push(lengths[i-1] + dist(points[i-1], points[i]));
    const length = lengths[lengths.length-1];
    function at(s) {
      if (s <= 0 || !length) return points[0];
      if (s >= length) return points[points.length-1];
      let lo = 0, hi = points.length-1;
      while (hi-lo > 1) {
        const m = (hi+lo) >> 1;
        if (lengths[m] < s) lo = m; else hi = m;
      }
      return lerp(points[lo], points[hi], (s-lengths[lo])/(lengths[hi]-lengths[lo]));
    }
    function frame(s) {
      const p = at(s), a = at(s-1.7), b = at(s+1.7);
      const t = unit(b[0]-a[0], b[1]-a[1]);
      return {p,t,n:[-t[1],t[0]]};
    }
    return {length,at,frame};
  }

  function sample(points) {
    const clean = [];
    for (const p of points || []) {
      if (Array.isArray(p) && Number.isFinite(p[0]) && Number.isFinite(p[1]) &&
          (!clean.length || dist(p,clean[clean.length-1]) > .15)) clean.push([p[0],p[1]]);
    }
    if (clean.length < 2) return clean;
    const raw = measure(clean);
    const count = Math.max(1, Math.ceil(raw.length/9));
    let poly = Array.from({length:count+1}, (_,i)=>raw.at(i*raw.length/count));
    for (let pass = 0; pass < 3; pass++) {
      const next = [poly[0]];
      for (let i=1;i<poly.length;i++) next.push(lerp(poly[i-1],poly[i],.25),lerp(poly[i-1],poly[i],.75));
      next.push(poly[poly.length-1]); poly=next;
    }
    const smooth = measure(poly), n = Math.max(1,Math.ceil(smooth.length/2.5));
    return Array.from({length:n+1},(_,i)=>smooth.at(i*smooth.length/n));
  }

  function smoothPath(points, start=true) {
    if (!points.length) return '';
    let d = start ? 'M'+xy(points[0]) : '';
    for (let i=1;i<points.length;i++) {
      const a=points[i-1], b=points[i], prev=points[Math.max(0,i-2)], next=points[Math.min(i+1,points.length-1)];
      d += 'C'+xy([a[0]+(b[0]-prev[0])/6,a[1]+(b[1]-prev[1])/6])+' '+
        xy([b[0]-(next[0]-a[0])/6,b[1]-(next[1]-a[1])/6])+' '+xy(b);
    }
    return d;
  }
  function curve(a,b,fn,step=5) {
    const count=Math.max(1,Math.ceil(Math.abs(b-a)/step));
    return Array.from({length:count+1},(_,i)=>fn(mix(a,b,i/count),i/count));
  }

  // A diminishing-radius volute joined with the exact incoming tangent.
  function volute(p,t,sign,r,angle) {
    const a=Math.atan2(t[1],t[0]), out=[p];
    const steps=Math.max(8,Math.ceil(angle*r/2));
    for(let i=0;i<steps;i++){
      const u=(i+.5)/steps, theta=a+sign*angle*u;
      const ds=r*angle/steps*Math.pow(1-u*.83,1.05);
      const last=out[out.length-1];
      out.push([last[0]+Math.cos(theta)*ds,last[1]+Math.sin(theta)*ds]);
    }
    return out;
  }

  const defaults = {method:'acanthus',fill:true,line:true,shade:false,hatch:false,rib:true,width:1,curl:.5,detail:1};
  function render(strokes, options) {
    const opt=Object.assign({},defaults,options||{});
    if (!['acanthus','cloth','scroll'].includes(opt.method)) opt.method='acanthus';
    const method=opt.method, detail=clamp(+opt.detail||1,.35,2);
    const ink='#362327', red='#ae282d', ivory='#fffdf5';
    const prefix=String(opt.idPrefix||'mantle').replace(/[^\w-]/g,'');
    let serial=0, defs='', marks='';
    const id = name => prefix + '-' + name;
    const url = k => 'url(#'+id(k)+')';
    const addDef = (tag,key,body,attrs='') => { defs+='<'+tag+' id="'+id(key)+'" '+attrs+'>'+body+'</'+tag+'>'; };
    function strokePath(d,w,color,extra='') {
      return '<path d="'+d+'" fill="none" stroke="'+color+'" stroke-width="'+fmt(w)+'" stroke-linecap="round" stroke-linejoin="round" '+extra+'/>';
    }
    if (opt.shade) {
      const gradient=(key,stops)=>addDef('linearGradient',key,stops.map(([s,c])=>'<stop offset="'+s+'%" stop-color="'+c+'"/>').join(''),'x1="0%" x2="65%" y1="0%" y2="100%"');
      gradient('silk',[[0,'#77252a'],[28,'#ae2930'],[50,'#dc4e47'],[69,'#b92c31'],[100,'#752028']]);
      gradient('lining',[[0,'#c2ada5'],[25,'#e6d9c9'],[47,'#fffdf4'],[72,'#f5efdf'],[100,'#c9b8ae']]);
      gradient('paper',[[0,'#cbcac1'],[45,'#fffef7'],[72,'#efede3'],[100,'#cac3b9']]);
    }
    function material(back) {
      if (opt.shade) return url(opt.fill ? (back?'lining':'silk') : 'paper');
      return opt.fill ? (back?ivory:red) : '#fffdf8';
    }

    function strand(points,settings) {
      if (points.length<2) return '';
      const spine=measure(points), L=spine.length, G=settings.guideLength || L;
      if (L<2) return '';
      const size=settings.size, sub=!!settings.sub;
      const flips=settings.flips || [], phase=settings.phase || 0;
      const asym= Math.sin(phase*1.37)>=0?1:-1;
      const folds=flips.map(v=>v*G).filter(x=>x>.75 && x<L-.75).sort((a,b)=>a-b);
      const limits=[0,...folds,L], memo=new Map();
      function width(s) {
        const u=s/L;
        // The root is gathered at the helm; it opens into a blade before tapering.
        let body=(.39+.65*Math.sin(Math.PI*Math.pow(clamp(u,0,1),.72))**.72);
        if (sub) body=(.19+.88*Math.sin(Math.PI*Math.pow(clamp(u,0,1),.67))**.7);
        const end=Math.min(1,(L-s)/Math.max(4,Math.min(L*.35,22)));
        let result=size*body*(.035+.965*Math.pow(Math.max(0,end),.75));
        if (s>G && L>G) result*=mix(1,.58,(s-G)/(L-G));
        for (const f of folds) {
          const v=Math.min(1,Math.abs(s-f)/(size*1.15+2));
          result*=.27+.73*Math.sin(v*PI/2);
        }
        return Math.max(.08,result);
      }
      function frame(s) {
        s=clamp(s,0,L);
        if (!memo.has(s)) {
          const f=spine.frame(s), a=spine.frame(Math.max(0,s-3)), b=spine.frame(Math.min(L,s+3));
          const turn=Math.atan2(a.t[0]*b.t[1]-a.t[1]*b.t[0],a.t[0]*b.t[0]+a.t[1]*b.t[1]);
          f.k=turn/Math.max(1,Math.min(L,s+3)-Math.max(0,s-3));
          let skew=0;
          for (const cut of folds) {
            const proximity=Math.max(0,1-Math.abs(s-cut)/(size*1.42+2));
            skew+=size*.62*proximity*proximity*asym;
          }
          f.skew=skew;
          memo.set(s,f);
        }
        return memo.get(s);
      }
      function pos(s,factor,along=0) {
        const f=frame(s);
        let offset=width(s)*factor;
        if (offset*f.k>.76) offset=.76/f.k;
        return move(f.p,f.t,f.n,along+f.skew*factor,offset);
      }

      // Each lobe is a shoulder, a hooked tip, then a deep re-entrant cut.
      // The two edges have independent counts and phases. Wide intervals also
      // place small ungrooved spans, keeping the whole sheet visually continuous.
      function edge(a,b,side,teeth) {
        const at=(s,k)=>pos(s,side*k);
        const lineTo=(start,end,fn)=>smoothPath(curve(start,end,fn),false);
        let d='', cursor=a;
        for (const tooth of teeth) {
          const {s,e,amp}=tooth;
          if(s>a && s>=cursor) d+=lineTo(cursor,s,q=>at(q,.71));
          const sidePoint=(u,offset)=>at(mix(s,e,u),offset);
          function cubic(a,b,c) { d+='C'+xy(sidePoint(...a))+' '+xy(sidePoint(...b))+' '+xy(sidePoint(...c)); }
          if (method==='cloth' && !sub) {
            cubic([.19,.58],[.30,.86],[.47,1.00*amp]);
            cubic([.64,1.17*amp],[.83,1.19*amp],[.94,1.01*amp]);
            cubic([.77,1.04*amp],[.52,.68],[.45,.24]);
            cubic([.43,.10],[.46,.05],[.50,.12]);
            cubic([.57,.40],[.79,.76],[1,.71]);
          } else {
            // The arched outer shoulder and curling nib contrast with the sharp sinus.
            cubic([.14,.72],[.20,1.13*amp],[.40,1.23*amp]);
            cubic([.58,1.38*amp],[.76,1.22*amp],[.85,.99*amp]);
            cubic([.70,1.06*amp],[.66,.92*amp],[.61,.82*amp]);
            cubic([.53,.66],[.55,.47],[.63,.36]);
            cubic([.70,.42],[.82,.76],[1,.71]);
          }
          cursor=e;
        }
        d+=lineTo(cursor,b,q=>at(q,.71));
        return d;
      }

      function makeTeeth(a,b,side) {
        const sense=side>0?1:-1, len=b-a, spacing=(method==='cloth'?23:method==='scroll'?33:19)/Math.sqrt(detail);
        const scaleFactor=clamp(size/9,.60,1.40);
        let s=a+Math.min(len*.19,spacing*.28)*(sense===asym?.65:1.85), i=0;
        const out=[];
        while(s<b-3 && i<90) {
          const rhythm=Math.sin(i*2.42+phase+sense+a*.035);
          const span=spacing*scaleFactor*(.98+.39*rhythm);
          const e=Math.min(b-.6,s+span);
          if(e-s>Math.min(span*.62,8) && width((e+s)/2)>(method==='cloth'?2.9:1.9) &&
            !(sub && method==='scroll' && (s/G>.4 || size<5.6)) && !(method==='scroll'&&sense!==asym) &&
            !(method==='cloth' && side!==asym && i%3!==1)) {
            const innerTurn=Math.max(0,frame((s+e)/2).k*side*size);
            const accent=(method==='scroll'?.90:1.14)+.21*Math.sin(i*2.05+phase+sense+a*.03);
            if(innerTurn<.57) out.push({s,e,amp:accent/(1+.8*innerTurn)});
          }
          s+=span*(method==='scroll'?1.45:1.06); i++;
        }
        return out;
      }
      function segment(a,b,back,idx) {
        const right=makeTeeth(a,b,1), left=makeTeeth(a,b,-1);
        // Build both edges in their natural direction, then reverse the lower
        // edge's cubic segments, keeping hooked teeth pointed the same way.
        const first=pos(a,.71), far=pos(b,-.71);
        const upper=edge(a,b,1,right), lower=edge(a,b,-1,left);
        const commands=lower.split('C').slice(1);
        const reversed=[];
        let prev=xy(pos(a,-.71));
        for(const command of commands) {
          const v=command.trim().split(/\s+/);
          reversed.push('C'+v[2]+' '+v[3]+' '+v[0]+' '+v[1]+' '+prev);
          prev=v[4]+' '+v[5];
        }
        const d='M'+xy(first)+upper+'L'+xy(far)+reversed.reverse().join('')+'Z';
        const key='b'+serial++;
        let front='<path d="'+d+'" fill="'+material(back)+'"/>';
        if (opt.line) front+=strokePath(d,sub?.66:.91,ink);
        // The turned-back lip on a leading shoulder shows the other textile
        // face even on a stroke without an explicit full half-turn.
        const candidates=(asym>0?right:left);
        if (!sub && opt.fill && candidates.length && b-a>22) {
          const tooth=candidates[Math.min(candidates.length-1,idx%2)], s=tooth.s, e=tooth.e, side=asym;
          const p=(u,f)=>xy(pos(mix(s,e,u),side*f));
          let lip;
          if(method==='cloth') lip='M'+p(.50,.12)+'Q'+p(.62,.69)+' '+p(.94,1.01*tooth.amp)+'Q'+p(.68,.76)+' '+p(.50,.12)+'Z';
          else lip='M'+p(.40,1.23*tooth.amp)+'Q'+p(.65,1.37*tooth.amp)+' '+p(.85,.99*tooth.amp)+'Q'+p(.66,1.12*tooth.amp)+' '+p(.40,1.23*tooth.amp)+'Z';
          front+='<path d="'+lip+'" fill="'+material(!back)+'" stroke="'+(opt.line?ink:'none')+'" stroke-width=".48"/>';
        }
        let inner='';
        const axis=s=>.12*asym*Math.sin((s/G)*TAU+phase);
        if (opt.shade) {
          const ra=curve(a,b,s=>pos(s,axis(s)-.32)), rb=curve(b,a,s=>pos(s,axis(s)-.17));
          inner+='<path d="'+smoothPath(ra)+'L'+xy(rb[0])+smoothPath(rb,false)+'Z" fill="#fff3dc" opacity=".23"/>';
          const band=curve(a,b,s=>pos(s,axis(s)+.42));
          inner+=strokePath(smoothPath(band),Math.min(size*.18,2.2),'#46212a','opacity=".14"');
        }
        if (opt.hatch) {
          const hatchColor=back||!opt.fill?'#56464a':'#501f27';
          const start=a+2;
          for(let s=start,i=0;s<b-1;s+=2.8,i++) {
            const side=asym, w=width(s), reach=.48+.23*Math.sin(s*.13+phase);
            const p0=pos(s,side*1.42), p1=pos(Math.min(b,s+1.8),side*.98);
            const p2=pos(Math.min(b,s+3.2+w*.18),side*reach*.53);
            inner+=strokePath('M'+xy(p0)+'Q'+xy(p1)+' '+xy(p2),.42,hatchColor,'opacity=".77"');
            if (i%2===0 && w>3.2) {
              const cross='M'+xy(pos(s,side*.48))+'Q'+xy(pos(Math.min(b,s+1.3),side*.84))+' '+xy(pos(Math.min(b,s+4.9),side*1.34));
              inner+=strokePath(cross,.39,hatchColor,'opacity=".69"');
            }
          }
        }
        if (opt.rib) {
          const ribEnd=sub && method==='scroll' ? Math.min(b,L*.68) : b;
          const rib=ribEnd>a ? curve(a,ribEnd,(s,u)=>pos(s,axis(s)+.055*Math.sin(PI*u))) : [];
          inner+=strokePath(smoothPath(rib),sub?.44:.66,back||!opt.fill?'#614942':'#692328','opacity=".92"');
          if(method==='acanthus'){
            for(const [side,set] of [[1,right],[-1,left]]){
              for(const {s,e,amp} of set){
                const pp=(u,v)=>xy(pos(mix(s,e,u),side*v));
                inner+=strokePath('M'+pp(.03,.06)+'C'+pp(.22,.15)+' '+pp(.32,.91*amp)+' '+pp(.52,1.02*amp),.47,back||!opt.fill?'#825f50':'#76252a','opacity=".82"');
              }
            }
          }
        }
        if (inner) {
          addDef('clipPath',key,'<path d="'+d+'"/>');
          front+='<g clip-path="'+url(key)+'">'+inner+'</g>';
        }
        return front;
      }

      let output='';
      // Subsidiary scrolls fork tangentially, then coil independently of the
      // user's main guide. Long slashed cloth instead divides into swallowtails.
      if (!sub && (method==='scroll'||method==='cloth') && G>39) {
        const count=method==='cloth'?Math.max(1,Math.min(2,Math.floor(G/95))):Math.min(3,Math.max(1,Math.floor(G*detail/63)));
        for(let j=0;j<count;j++){
          const u=method==='cloth'?.34+.48*(j+1)/(count+.5):.20+.54*(j+.35)/(count+.12);
          const f=frame(G*u), sign=asym*(j%2?-1:1), span=clamp(G*(method==='cloth'?.27:.225),12,method==='cloth'?40:32);
          const branch=curve(0,1,(_,v)=>move(f.p,f.t,f.n,span*(.95*v-.23*v*v),sign*span*(.08*v+.72*v*v)),.12);
          const tip=branch[branch.length-1], prev=branch[branch.length-2], t=unit(tip[0]-prev[0],tip[1]-prev[1]);
          const weight=.70+.22*Math.sin(phase+j*2.63+.5);
          const spiral=volute(tip,t,sign,span*(method==='cloth'?.31:.34+.17*weight),method==='cloth'?2.25:3.85+weight);
          const branchSpine=branch.concat(spiral.slice(1));
          const parentBack=!!settings.back !== (folds.filter(v=>v<G*u).length%2===1);
          output+=strand(branchSpine,{sub:true,size:size*(method==='cloth'?.76:weight),back:method==='cloth'?!parentBack:parentBack,phase:phase+j+2,flips:method==='cloth'?[.55]:weight>.75?[.49]:[]});
        }
      }
      for(let i=0;i<limits.length-1;i++) output+=segment(limits[i],limits[i+1],!!settings.back !== (i%2===1),i);
      // At a half-turn a narrow sliver of the preceding face rolls over the
      // following sheet. The oblique gathering above and this curved crease
      // remain readable even without gradients or hatch marks.
      if(opt.fill || opt.line || opt.shade) folds.forEach((f,index)=>{
        const hand=index%2===0?asym:-asym;
        const h=Math.min(size*.90,(limits[index+2]-f)*.38,(f-limits[index])*.42);
        if(h<1) return;
        const p=(ds,off)=>xy(pos(f+h*ds,hand*off));
        const lip='M'+p(0,-.70)+'C'+p(-.09,-.24)+' '+p(.27,.18)+' '+p(.94,.63)+
          'C'+p(.69,.63)+' '+p(.31,.54)+' '+p(0,.70)+'Q'+p(.14,.06)+' '+p(0,-.70)+'Z';
        const before=!!settings.back !== (index%2===1);
        output+='<path d="'+lip+'" fill="'+material(before)+'" stroke="'+(opt.line?ink:'none')+'" stroke-width=".48"/>';
        if(opt.shade) output+=strokePath('M'+p(.09,-.27)+'Q'+p(.35,.27)+' '+p(.82,.57),.70,'#5c4241','opacity=".36"');
      });
      return output;
    }

    if (opt.fill || opt.line || opt.shade || opt.hatch || opt.rib) {
      (strokes||[]).forEach((stroke,index)=>{
        const points=sample(stroke.points);
        if(points.length<2) return;
        const guide=measure(points), G=guide.length, end=guide.frame(G), curl=clamp(Number(stroke.curl??opt.curl)||0,-1,1);
        const size=(method==='cloth'?13.9:method==='acanthus'?12.7:8.7)*clamp(+opt.width||1,.2,2.5)*clamp(+stroke.scale||1,.15,2)*Math.min(1,Math.sqrt(G/62));
        let body=points;
        if(Math.abs(curl)>.015){
          const magnitude=Math.abs(curl);
          const radius=clamp(G*.125,3,17)*(method==='scroll'?1.18:1);
          const terminal=volute(end.p,end.t,Math.sign(curl),radius,(method==='scroll'?5.8:4.85)*magnitude);
          body=body.concat(terminal.slice(1));
        }
        marks+=strand(body,{guideLength:G,size,back:!!stroke.back,
          phase:index*2.31+.8,flips:Array.isArray(stroke.twists)?stroke.twists.filter(Number.isFinite):[]});
      });
    }
    const half=id('half');
    return '<defs>'+defs+'<g id="'+half+'">'+marks+'</g></defs><use href="#'+half+'" xlink:href="#'+half+'" xmlns:xlink="http://www.w3.org/1999/xlink"/><use href="#'+half+'" xlink:href="#'+half+'" xmlns:xlink="http://www.w3.org/1999/xlink" transform="translate(400 0) scale(-1 1)"/>';
  }
  return Object.freeze({render,sample});
});
