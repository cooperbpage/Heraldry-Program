/* Reproduce the nine design studies with the local production engine:
 * node render-comparison.js > Comparison.svg
 * inkscape Comparison.svg --export-filename=Comparison.png
 */
'use strict';
const { render } = require('./engine.js');
const { presets, helmet } = require('./studies.js');

const methods = [
  ['acanthus', 'Acanthus'],
  ['cloth', 'Slashed cloth'],
  ['scroll', 'Scrollwork']
];
const panels = [];
Object.entries(presets).forEach(([key, strokes], row) => {
  methods.forEach(([method, label], column) => {
    const title = key[0].toUpperCase() + key.slice(1) + ' · ' + label;
    const art = render(strokes, {
      method, idPrefix: key + '-' + method, shade: row === 2, hatch: row === 1
    });
    panels.push(`<g transform="translate(${column * 400} ${row * 345})">
      <text x="200" y="19" font-family="serif" font-size="14" text-anchor="middle">${title}</text>
      <g transform="translate(0 20)">${art}${helmet}</g>
    </g>`);
  });
});
process.stdout.write(`<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="1020">
  <rect width="100%" height="100%" fill="#faf7ef"/>${panels.join('\n')}</svg>`);
