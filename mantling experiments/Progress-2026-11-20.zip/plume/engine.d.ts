/** Editable right-half guides in the 400 × 370 achievement coordinate system. */
export type Point = [number, number];
export interface MantlingStroke {
  points: Point[];
  /** Fractions of the smoothed guide length at which the visible face changes. */
  twists?: number[];
  /** Strength and direction of terminal curl, −1 to 1. Zero ends at the last point. */
  curl?: number;
  scale?: number;
  back?: boolean;
}
export interface RenderOptions {
  method?: 'acanthus' | 'cloth' | 'scroll';
  fill?: boolean;
  line?: boolean;
  shade?: boolean;
  hatch?: boolean;
  rib?: boolean;
  width?: number;
  detail?: number;
  curl?: number;
  /** Unique prefix when inserting several results in the same document. */
  idPrefix?: string;
}
export function render(strokes: MantlingStroke[], options?: RenderOptions): string;
export function sample(points: Point[]): Point[];
export as namespace Mantling;
