'use strict';
(() => {
  const G=Geometry, M=MantlingModel, $=s=>document.querySelector(s), all=s=>[...document.querySelectorAll(s)];
  const plate=$('#plate'), presets=JSON.parse($('#data').textContent);
  const history=M.snapshotHistory(), ns='mantling-event-studies-2';
  const settings={smoothing:.72,fill:true,line:true,rib:true,shade:true,hatch:false,guides:false,generative:false};
  let doc=M.copy(presets.lion), tool='sweep', selected=null, mark=null, drag=null, redraw=false, placed=[], guides=[], serial=0;
  function hydrate(d){
    const ids=new Set();
    M.walk(d,el=>{
      if(!el.events)el.events=[];
      for(const obj of [el,...el.events]){
        if(!obj.id||ids.has(obj.id))obj.id=uid();
        ids.add(obj.id);
      }
    });return d;
  }
  function uid(){return 'hand-'+Date.now().toString(36)+'-'+(++serial);}
  hydrate(doc);doc.preset='lion';
  try{const saved=JSON.parse(localStorage.getItem(ns));if(saved?.doc&&Array.isArray(saved.doc.roots)){doc=hydrate(saved.doc);Object.assign(settings,saved.settings);}}catch{}
  const setToolHints={
    sweep:'Draw from root to tip on either side. To reshape a stem, select it and choose Redraw.',
    cluster:'Drag along one edge to bracket the foliage. Tap a bracket to edit it.',
    branch:'Start on a stem and sweep outward to fork. Tap an existing fork to edit it.',
    width:'Spread two fingers over a stem, or pull outward from it with one. Tap a width mark to edit it.',
    volute:'Start on a stem and drag toward the eye of the coil. The eye snaps to the tangent-compatible position.',
    fold:'Drag diagonally from one edge across the stem to lay a fold. Tap its mark to edit it.'
  };
  const hist=(s,it=false)=>(it?s.replace(/ss/g,'ß'):s).replace(/s(?=[A-Za-zſß])/g,'ſ');
  function applyType(parent){
    const w=document.createTreeWalker(parent,NodeFilter.SHOW_TEXT);
    while(w.nextNode()){const n=w.currentNode;if(!n.parentElement.closest('script,style'))n.textContent=hist(n.textContent,!!n.parentElement.closest('i'));}
  }
  applyType(document.body);
  const say=text=>$('#hint').textContent=hist(text);
  function remember(){try{localStorage.setItem(ns,JSON.stringify({doc,settings}));}catch{}}
  function change(fn,notice){
    const old=M.copy(doc);fn();
    if(JSON.stringify(old)!==JSON.stringify(doc)){history.record(old);doc.preset='drawing';}
    render();say(notice||setToolHints[tool]);
  }
  function freshSeed(){const buf=new Uint32Array(1);crypto.getRandomValues(buf);return buf[0];}
  function replaceDoc(next,label){
    history.record(doc);doc=hydrate(next);selected=null;mark=null;redraw=false;render();say(label||setToolHints[tool]);
  }
  function project(spine,p){
    // Coarse arc-length samples bracket the nearest point. Refine only that interval.
    const pts=guides.find(g=>g.spine===spine)?.samples||Array.from({length:41},(_,i)=>G.frame(spine,i/40).p);
    let best={d:Infinity,t:0};
    for(let j=1;j<pts.length;j++){
      const a=pts[j-1],b=pts[j],x=b[0]-a[0],y=b[1]-a[1];
      const v=M.clamp(((p[0]-a[0])*x+(p[1]-a[1])*y)/(x*x+y*y||1),0,1);
      const d=M.distance(p,[a[0]+v*x,a[1]+v*y]);if(d<best.d)best={d,t:(j-1+v)/(pts.length-1)};
    }
    const f=G.frame(spine,best.t);
    return {...best,...f,across:(p[0]-f.p[0])*f.normal[0]+(p[1]-f.p[1])*f.normal[1]};
  }
  function point(ev){const p=new DOMPoint(ev.clientX,ev.clientY).matrixTransform(plate.getScreenCTM().inverse());return [M.clamp(doc.mirror?200+Math.abs(p.x-200):p.x,0,400),M.clamp(p.y,0,370)];}
  const current=()=>placed.find(p=>p.element.id===selected);
  function nearest(p){
    let best;
    for(const row of placed){const hit=project(row.spine,p);
      if(!best||hit.d<best.d)best={...hit,row};
    }return best;
  }
  function eligible(el){return tool==='width'?el.width.map((w,i)=>({id:'w'+i,t:w[0]})):el.events.filter(e=>e.type===tool);}
  const station=e=>e.type==='cluster'?(e.t0+e.t1)/2:e.t;
  function chosen(){return current()&&eligible(current().element).find(e=>e.id===mark);}
  function handles(row,e){
    const at=t=>G.frame(row.spine,t);
    if(e.type==='cluster'){return [at(e.t0).p,at(station(e)).p,at(e.t1).p];}
    if(e.type==='volute'&&G.eye)return [at(e.t).p,G.eye(row.spine,e)];
    return [at(station(e)).p];
  }
  function nearestMark(p){
    let best;
    for(const row of placed)for(const e of eligible(row.element)){
      for(const [i,v] of handles(row,e).entries()){
        const d=M.distance(p,v);if(!best||d<best.d)best={d,e,row,index:i};
      }
    }return best?.d<=9?best:null;
  }
  function option(select,value,label){const o=document.createElement('option');o.value=value;o.textContent=hist(label);select.append(o);}
  function ranges(){
    const panel=$('#edit');panel.textContent='';
    const row=current(), el=row?.element, e=chosen();
    const button=(label,act)=>{const b=document.createElement('button');b.type='button';b.textContent=hist(label);b.onclick=act;panel.append(b);return b;};
    const range=(label,value,min,max,step,act)=>{
      const l=document.createElement('label'),v=document.createElement('input'),n=document.createElement('output');
      l.append(hist(label)+' ');v.type='range';Object.assign(v,{min,max,step,value});v.setAttribute('aria-label',label);l.append(v,n);panel.append(l);n.textContent=fmt(value);v.oninput=()=>n.textContent=fmt(+v.value);v.onchange=()=>mutate(()=>act(+v.value));
    };
    const fmt=v=>String(Math.round(v*100)/100);
    const mutate=act=>{
      if(!el)return;const candidate=M.copy(doc);
      act();
      if(M.clustersUsed(el.events)>.600001){doc=candidate;render();say('Keep at least forty percent of the stem bare.');return;}
      if(JSON.stringify(doc)!==JSON.stringify(candidate)){
        M.keep(doc,el,e);history.record(candidate);doc.preset='drawing';
      }render();
    };
    if(tool==='sweep'&&el){
      button(redraw?'Cancel redraw':'Redraw selected',()=>{redraw=!redraw;ranges();say(redraw?'Draw the new course of the selected stem.':setToolHints.sweep);});
      button('Remove stem',()=>change(()=>{const parent=findParent(el);if(parent)parent.el.events=parent.el.events.filter(v=>v!==parent.e);else doc.roots=doc.roots.filter(v=>v!==el);selected=null;mark=null;}));
      return;
    }
    if(!e)return;
    if(tool==='width'){
      const i=+e.id.slice(1),w=el.width[i];
      range('Half width',w[1],.15,40,.15,v=>w[1]=v);
      if(i>0&&i<el.width.length-1)button('Remove knot',()=>mutate(()=>{el.width.splice(i,1);mark=null;}));
      return;
    }
    if(e.type==='cluster'){
      range('Beginning',e.t0,0,e.t1-.015,.005,v=>e.t0=v);range('End',e.t1,e.t0+.015,1,.005,v=>e.t1=v);
      range('Size',e.size,.25,3,.05,v=>e.size=v);range('Depth',e.depth,1,3,1,v=>e.depth=v);
      const shares=Array.isArray(e.splits)?e.splits.slice():Array(Math.max(2,Math.min(4,e.splits||3))).fill(.4);
      range('Leaflets',shares.length,2,4,1,count=>{e.splits=Array.from({length:count},(_,i)=>shares[i]||.4);});
      shares.forEach((share,i)=>range('Leaflet '+(i+1)+' weight',share,.05,2,.05,v=>{e.splits=shares.slice();e.splits[i]=v;}));
      button('Other edge',()=>mutate(()=>e.side*=-1));
    }else{
      range('Station',e.t,0,1,.005,v=>e.t=v);
      if(e.type==='branch'){button('Redraw fork',()=>{selected=e.child.id;tool='sweep';mark=null;redraw=true;render();say('Draw the new course of this branch. Its root stays attached.');});}
      if(e.type==='fold'){
        range('Length',e.length,.025,.38,.005,v=>e.length=v);
        button('Other edge',()=>mutate(()=>e.edge*=-1));
      }
      if(e.type==='volute'){
        range('Radius',e.radius,2,60,.5,v=>e.radius=v);range('Turns',e.turns,.38,2.1,.02,v=>e.turns=v);
        range('Tightening',e.tightening,.10,.7,.01,v=>e.tightening=v);
        button('Other hand',()=>mutate(()=>e.hand*=-1));
      }
    }
    button('Remove mark',()=>mutate(()=>{el.events=el.events.filter(v=>v!==e);mark=null;}));
  }
  function findParent(child){
    let res=null;M.walk(doc,(el,p,e)=>{if(el===child&&p)res={el:p,e};});return res;
  }
  function updateLists(){
    const s=$('#target');s.textContent='';option(s,'','Nearest');
    const names=new Map();
    function add(el,name){names.set(el.id,name);option(s,el.id,name);let j=0;for(const e of el.events)if(e.type==='branch')add(e.child,name+'·'+(++j));}
    doc.roots.forEach((el,i)=>add(el,'Sweep '+(i+1)));
    if(!names.has(selected))selected=null;s.value=selected||'';
    const list=$('#event');list.textContent='';option(list,'','New');
    const entries=current()?eligible(current().element):[];entries.forEach(e=>option(list,e.id,Math.round(station(e)*100)+'%'));
    if(!entries.some(e=>e.id===mark))mark=null;
    list.value=mark||'';$('#eventLabel').hidden=tool==='sweep';
  }
  const path=pts=>pts.map((p,i)=>(i?'L':'M')+p.map(n=>n.toFixed(2)).join(',')).join('');
  const dot=(p,r,sel)=>'<circle class="mark '+(sel?'picked':'')+'" cx="'+p[0]+'" cy="'+p[1]+'" r="'+r+'"/>';
  function overlay(){
    let svg='';
    if(settings.guides||tool!=='sweep'||redraw){
      for(const row of guides){
        svg+='<path class="guide" d="'+path(row.samples)+'"/>';
        if(tool!=='sweep')for(const e of eligible(row.element)){
          const active=e.id===mark&&row.element.id===selected, pts=handles(row,e);
          for(const p of pts)svg+=dot(p,active?2.8:1.9,active);
          if(active&&pts.length>1)svg+='<path class="guide" d="'+path(pts)+'"/>';
        }
      }
    }
    if(drag){svg+='<path class="ghost" d="'+path(drag.pts)+'"/>';
      if(tool==='volute'&&drag.near&&drag.pts.length>1){
        const spiral=eyeParams(drag.near,drag.pts[drag.pts.length-1]), f=drag.near;
        const pole=G.eye?G.eye(f.row.spine,{type:'volute',t:f.t,...spiral}):drag.pts[drag.pts.length-1];
        svg+=dot(pole,3,true)+'<circle class="guide" cx="'+pole[0]+'" cy="'+pole[1]+'" r="'+spiral.radius+'"/>';
      }
    }
    $('#overlay').innerHTML=svg+(doc.mirror?'<g transform="translate(400 0) scale(-1 1)">'+svg+'</g>':'');
  }
  function render(){
    placed=G.placed(doc);guides=placed.map(r=>({...r,samples:Array.from({length:45},(_,i)=>G.frame(r.spine,i/44).p)}));
    $('#art').innerHTML=G.render(doc,settings);
    updateLists();ranges();overlay();
    all('[data-tool]').forEach(b=>b.setAttribute('aria-pressed',b.dataset.tool===tool));
    all('[data-opt]').forEach(b=>b.checked=!!settings[b.dataset.opt]);
    for(const key of ['guides','generative'])$('#'+key).checked=settings[key];
    $('#smoothing').value=settings.smoothing;$('#smoothVal').textContent=Math.round(settings.smoothing*100)+'%';
    $('#presets').value=doc.preset||'drawing';$('#undo').disabled=!history.canUndo;$('#redo').disabled=!history.canRedo;
    $('#reseed').disabled=!doc.roots.length||doc.roots.length>3;$('#reset').disabled=!doc.roots.length;
    remember();
  }
  function eyeParams(f,p,tightening=.26){
    const dx=p[0]-f.p[0],dy=p[1]-f.p[1],n=dx*f.normal[0]+dy*f.normal[1],hand=n<0?-1:1;
    const unit=G.eye(f.row.spine,{type:'volute',t:f.t,hand,radius:10,tightening,turns:1});
    const vx=(unit[0]-f.p[0])/10,vy=(unit[1]-f.p[1])/10;
    return {hand,radius:M.clamp((dx*vx+dy*vy)/(vx*vx+vy*vy||1),2,60),tightening,turns:1};
  }
  function finish(g){
    const pts=g.pts,end=pts[pts.length-1],moved=pts.slice(1).reduce((s,p,i)=>s+M.distance(p,pts[i]),0);
    const pick=g.marker;
    if(tool!=='sweep'&&pick&&moved<5){selected=pick.row.element.id;mark=pick.e.id;render();say('Use the controls below to adjust this mark.');return;}
    let f=g.near;
    if(tool!=='sweep'&&!f){overlay();say('Begin on an existing stem.');return;}
    if(tool==='sweep'){
      if(moved<6){if(f){selected=f.row.element.id;mark=null;render();}return;}
      if(!redraw&&settings.generative&&doc.roots.length>=3){say('Compose takes up to three main sweeps. Reset or redraw a selected stem.');overlay();return;}
      const spine=G.fit(pts,settings.smoothing);
      if(!spine.length)return;
      const target=redraw?current():null;
      change(()=>{
        if(target){const el=target.element;M.keep(doc,el);el.spine=spine;
          // Edited child directions are authored in world coordinates.
          const parent=findParent(el);
          if(parent){
            const parentRow=placed.find(row=>row.element===parent.el);
            parent.e.departure=M.departure(parentRow.spine,parent.e.t,spine);
          }
        }else{const el=M.newStrip(uid(),spine);doc.roots.push(el);selected=el.id;}
        if(settings.generative&&!target)doc=M.decorate(doc,freshSeed());redraw=false;mark=null;
      },'Fitted '+spine.length+' cubic segment'+(spine.length===1?'':'s')+'.');return;
    }
    if(tool==='width'&&moved<1&&!pick){selected=f.row.element.id;render();say('Pull outward across the stem to set its width.');return;}
    if(!pick&&f.d>Math.max(18,G.widthAt(f.row.element,f.t)+10)){overlay();say('Begin closer to the stem or its edge.');return;}
    const editing=pick&&moved>=5&&pick.e.id===mark&&selected===pick.row.element.id;
    if(editing){const row=pick.row,e=pick.e,t=station(e);f={...G.frame(row.spine,t),t,row,across:1};}
    const el=f.row.element, hit=project(f.row.spine,end);
    const old=M.copy(doc);let e=editing?pick.e:null;
    if(tool==='width'){
      const across=(end[0]-f.p[0])*f.normal[0]+(end[1]-f.p[1])*f.normal[1];
      let knot=e?el.width[+e.id.slice(1)]:el.width.find(w=>Math.abs(w[0]-f.t)<.035);
      if(!knot){knot=[f.t,0];el.width.push(knot);el.width.sort((a,b)=>a[0]-b[0]);}
      knot[1]=M.clamp(Math.abs(across),.15,40);mark='w'+el.width.indexOf(knot);
    }else{
      if(!e){e={id:uid(),type:tool,t:f.t};el.events.push(e);}
      if(tool==='cluster'){
        if(editing&&pick.index!==1){if(pick.index===0)e.t0=M.clamp(hit.t,0,e.t1-.02);else e.t1=M.clamp(hit.t,e.t0+.02,1);}
        else if(editing){const span=e.t1-e.t0;e.t0=M.clamp(hit.t-span/2,0,1-span);e.t1=e.t0+span;}
        else{const span=Math.max(.09,Math.abs(f.t-hit.t));e.t0=M.clamp(Math.min(f.t,hit.t),0,1-span);e.t1=e.t0+span;e.side=f.across>=0?1:-1;e.size=1.4;e.depth=2;e.splits=[.24,.48,.28];delete e.t;}
        if(M.clustersUsed(el.events)>.600001){doc=old;render();say('Keep at least forty percent of the stem bare.');return;}
      }else if(tool==='branch'){
        if(moved<5){doc=old;render();say('Draw outward from the parent to form a fork.');return;}
        if(editing){e.t=hit.t;}
        else{
          e.side=f.across<0?-1:1;
          const childSpine=G.fit([f.p,...pts.slice(1)],settings.smoothing);
          e.departure=M.departure(f.row.spine,f.t,childSpine);
          e.child=M.newStrip(uid(),childSpine,Math.max(2,G.widthAt(el,f.t)*.72));
        }
      }else if(tool==='fold'){
        const edge=editing?e.edge:(f.across<0?-1:1);
        const start=editing?f.t:Math.min(f.t,hit.t);
        Object.assign(e,{t:start,edge,length:M.clamp(Math.abs(hit.t-f.t)||.09,.035,.38)});
      }else if(tool==='volute'){
        const t=editing?e.t:(f.t>.965?1:f.t);const v=eyeParams({...f,...G.frame(f.row.spine,t),t},end,e.tightening??.26);
        if(!editing&&t===1&&el.width[el.width.length-1][1]<1)el.width[el.width.length-1][1]=Math.min(v.radius*.26,G.widthAt(el,.7));
        Object.assign(e,v,{t,turns:e.turns||1});
      }
      mark=e.id;
    }
    M.keep(doc,el,e);selected=el.id;doc.preset='drawing';history.record(old);render();
  }
  plate.addEventListener('pointerdown',ev=>{
    if(ev.button!==0)return;
    if(drag){
      if(tool==='width'&&!drag.pinch&&drag.id!==ev.pointerId){
        ev.preventDefault();const a=drag.pts[0],b=point(ev);
        const middle=[(a[0]+b[0])/2,(a[1]+b[1])/2], hit=nearest(middle);
        if(hit&&hit.d<=20){
          drag.pinch={second:ev.pointerId,a,b,hit};
          plate.setPointerCapture(ev.pointerId);
        }
      }
      return;
    }
    ev.preventDefault();
    const p=point(ev);let near=nearest(p);const marker=tool==='sweep'?null:nearestMark(p);
    if(marker)near={...project(marker.row.spine,p),row:marker.row};
    drag={id:ev.pointerId,pts:[p],near,marker};plate.setPointerCapture(ev.pointerId);overlay();
  });
  plate.addEventListener('pointermove',ev=>{
    if(drag?.pinch){
      if(ev.pointerId===drag.id)drag.pinch.a=point(ev);
      if(ev.pointerId===drag.pinch.second)drag.pinch.b=point(ev);
      drag.pts=[drag.pinch.a,drag.pinch.b];overlay();return;
    }
    if(!drag||ev.pointerId!==drag.id)return;
    const events=ev.getCoalescedEvents?.()||[];
    for(const v of events.length?events:[ev]){const p=point(v);if(M.distance(p,drag.pts[drag.pts.length-1])>1.3)drag.pts.push(p);}
    overlay();
  });
  plate.addEventListener('pointerup',ev=>{
    if(drag?.pinch&&(ev.pointerId===drag.id||ev.pointerId===drag.pinch.second)){
      const {a,b,hit}=drag.pinch,el=hit.row.element;drag=null;
      change(()=>{
        let w=el.width.find(k=>Math.abs(k[0]-hit.t)<.035);
        if(!w){w=[hit.t,0];el.width.push(w);el.width.sort((l,r)=>l[0]-r[0]);}
        w[1]=M.clamp(M.distance(a,b)/2,.15,40);M.keep(doc,el);
        selected=el.id;mark='w'+el.width.indexOf(w);
      });return;
    }
    if(!drag||ev.pointerId!==drag.id)return;const g=drag;drag=null;
    const end=point(ev);if(M.distance(end,g.pts[g.pts.length-1])>.6)g.pts.push(end);
    finish(g);overlay();
  });
  const cancel=()=>{drag=null;overlay();};plate.addEventListener('pointercancel',cancel);plate.addEventListener('lostpointercapture',cancel);
  all('[data-tool]').forEach(b=>b.onclick=()=>{tool=b.dataset.tool;mark=null;redraw=false;render();say(setToolHints[tool]);});
  $('#target').onchange=ev=>{selected=ev.target.value||null;mark=null;redraw=false;render();};
  $('#event').onchange=ev=>{mark=ev.target.value||null;render();};
  $('#presets').onchange=ev=>{const key=ev.target.value;if(presets[key])replaceDoc({...M.copy(presets[key]),preset:key});};
  $('#reset').onclick=()=>replaceDoc({mirror:true,roots:[],preset:'drawing'},'Blank sheet. Draw a sweep from the helm.');
  $('#undo').onclick=()=>{doc=history.undo(doc);mark=null;redraw=false;render();};
  $('#redo').onclick=()=>{doc=history.redo(doc);mark=null;redraw=false;render();};
  $('#reseed').onclick=()=>change(()=>{doc=M.decorate(doc,freshSeed());},'New ornaments on the same main sweeps.');
  for(const key of ['guides','generative'])$('#'+key).onchange=ev=>{settings[key]=ev.target.checked;render();if(key==='generative')say('Draw one to three sweeps on a blank sheet. Reseed recomposes their ornaments.');};
  $('#smoothing').oninput=ev=>{settings.smoothing=+ev.target.value;$('#smoothVal').textContent=Math.round(settings.smoothing*100)+'%';remember();};
  all('[data-opt]').forEach(b=>b.onchange=()=>{settings[b.dataset.opt]=b.checked;render();});
  $('#export').onclick=()=>{
    const svg='<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="800" height="740" viewBox="0 0 400 370">'+$('#art').innerHTML+$('#helm').innerHTML+'</svg>';
    const url=URL.createObjectURL(new Blob([svg],{type:'image/svg+xml'}));const a=document.createElement('a');a.href=url;a.download='Mantling.svg';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);
  };
  render();say(setToolHints[tool]);
})();
