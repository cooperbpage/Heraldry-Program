/* The measured guides are authored in the right half of a 400-unit field.
 * Branch joins use the nearest point of their parent's Bézier. All handedness,
 * lengths and profiles below are explicit design choices. Run with Node. */
const fs=require('node:fs'), G=require('./geometry.js');
const model=require('./model.js');
const mantle=(...roots)=>({mirror:true,roots});
const strip=(id,points,width,...events)=>({id,spine:G.interpolate(points),width,events});
const cluster=(t0,t1,side,size,depth=1,splits=[.43,.34,.23])=>({type:'cluster',t0,t1,side,size,depth,splits});
const fold=(t,length,edge)=>({type:'fold',t,length,edge});
const scroll=(radius,hand,turns=.82)=>({type:'volute',t:1,radius,hand,turns,tightening:.245});
function fork(parent,child){
  const start=child.spine[0][0];let t=0,best=Infinity;
  for(let i=0;i<=240;i++){const p=G.frame(parent.spine,i/240).p,d=Math.hypot(p[0]-start[0],p[1]-start[1]);if(d<best){best=d;t=i/240;}}
  parent.events.push({type:'branch',t,side:0,child});
}
const taper=(a,b,c,end=.3)=>[[0,a],[.31,b],[.74,c],[1,end]];

function lion(){
  const silver=strip('lion-silver',[[201,114],[220,126],[249,129],[278,121],[304,105],[311,104],[314,108],[310,111]],[[0,6],[.22,9],[.52,10],[.82,7],[1,1]],fold(.08,.13,-1),cluster(.48,.92,1,1.65,2,[.56,.44]));
  fork(silver,strip('lion-low-dagge',[[217,122],[235,134],[256,145],[277,151],[289,150],[295,144],[291,141]],taper(4,9,7,1),cluster(.50,.94,1,1.55,2,[.45,.55])));
  fork(silver,strip('lion-inner-plait',[[218,125],[241,132],[265,135],[292,129],[306,125],[311,119],[306,117]],taper(4,7.5,6.5,1),cluster(.53,.94,1,1.42,2,[.39,.61])));
  const mantleTop=strip('lion-canopy',[[201,108],[221,114],[248,110],[269,95],[287,77],[310,72],[329,81],[337,98],[351,108]],[[0,6],[.2,10],[.45,5],[.59,3],[.79,5],[.94,7],[1,.25]],cluster(.03,.26,1,1.28,1,[.36,.4,.24]),cluster(.80,.98,-1,1.55,1,[.5,.30,.2]));
  fork(mantleTop,strip('lion-fan',[[225,113],[238,105],[252,88],[265,79],[279,81]],taper(6,11,7),fold(.10,.12,1),cluster(.29,.78,-1,1.62,1,[.55,.45])));
  fork(mantleTop,strip('lion-upright',[[300,74],[307,63],[306,50],[299,40],[287,37],[278,43]],[[0,4],[.27,5],[.53,9],[.78,5.5],[1,3.3]],cluster(.21,.54,1,1.22,1,[.52,.48]),scroll(9,-1,.85)));
  const lower=strip('lion-eye',[[329,82],[333,95],[337,112],[350,126],[355,143],[348,155]],taper(4,8,7,5.4),cluster(.27,.59,-1,1.45,1,[.65,.35]),scroll(18,1,.94));
  fork(lower,strip('lion-lower-counter',[[339,115],[328,111],[319,115],[318,125],[328,132]],taper(3,6,6,3.8),scroll(11,-1,.85)));
  fork(lower,strip('lion-red-tail',[[352,139],[362,141],[367,147],[378,148]],taper(4,6,5),cluster(.30,.82,-1,1.50,1,[.47,.53])));
  fork(mantleTop,lower);
  const crownLip=strip('lion-outer-wreath',[[202,113],[227,122],[255,121],[281,109],[304,107],[322,114]],[[0,6],[.26,10],[.57,8],[.78,7],[1,4]],cluster(.16,.50,1,1.2,1,[.28,.44,.28]),scroll(12,1,.76));
  return mantle(silver,mantleTop,crownLip);
}

function stirling(){
  const gather=strip('stirling-gather',[[201,112],[219,121],[236,135],[253,139],[268,131],[279,112]],[[0,7],[.24,15],[.58,19],[.83,16],[1,1]],fold(.09,.14,1),cluster(.37,.82,1,1.25,2,[.42,.58]));
  fork(gather,strip('stirling-train',[[219,122],[237,149],[258,160],[278,156],[284,147]],taper(6,17,13),cluster(.34,.76,1,1.22,1,[.28,.48,.24])));
  fork(gather,strip('stirling-ruffle',[[214,119],[225,143],[244,159],[258,164],[273,163]],taper(6,12,9),cluster(.39,.84,1,1.12,1,[.58,.42])));
  const hood=strip('stirling-hood',[[204,110],[221,105],[231,89],[242,73],[261,65],[277,68]],taper(5,8,10,3.6),fold(.68,.15,-1),cluster(.28,.53,-1,1.5,1,[.59,.41]),scroll(12,1,.76));
  fork(hood,strip('stirling-ruff',[[224,99],[234,91],[245,90],[250,98],[247,108]],taper(3,6,4,1.9),scroll(6,1,.8)));
  const crown=strip('stirling-tuft',[[205,109],[220,99],[234,95],[251,101],[262,112],[277,116],[286,104],[288,84]],[[0,5],[.23,6],[.46,3.8],[.68,9],[.86,15],[1,.4]],cluster(.68,.98,-1,1.7,1,[.37,.63]),cluster(.68,.96,1,1.35,2,[.56,.44]));
  fork(crown,strip('stirling-lower-scroll',[[269,114],[279,130],[277,148],[267,161],[255,168],[245,163]],taper(5,8,8,3.4),cluster(.42,.67,-1,1.18,1,[.6,.4]),scroll(10,1,.86)));
  fork(crown,strip('stirling-rising-tip',[[279,116],[287,113],[296,103],[303,88],[300,77]],taper(5,10,9),cluster(.42,.93,-1,1.25,2,[.55,.45])));
  return mantle(gather,hood,crown);
}

function stag(){
  const white=strip('stag-fan',[[201,112],[220,123],[243,124],[266,114],[291,101],[303,94],[303,88],[298,87]],[[0,6],[.22,9],[.52,10],[.80,5],[.90,5.5],[1,.75]],fold(.06,.09,1),cluster(.57,.94,1,2.3,2,[.58,.42]));
  fork(white,strip('stag-low',[[216,121],[237,142],[263,153],[286,156],[298,156],[303,151],[300,148]],taper(5,7,6,1.1),cluster(.55,.98,1,1.65,2,[.40,.60])));
  fork(white,strip('stag-middle',[[226,125],[247,133],[273,132],[294,124],[308,121],[311,114],[305,113]],taper(5,7,7,.85),cluster(.56,.96,1,1.8,2,[.42,.58])));
  fork(white,strip('stag-high-ridge',[[219,121],[235,112],[245,96],[247,82],[253,73],[260,72],[257,77]],taper(4,6,5,1),cluster(.52,.92,-1,1.6,2,[.46,.54])));
  fork(white,strip('stag-upper-ridge',[[225,124],[245,113],[261,96],[274,80],[285,73],[291,74],[289,80]],taper(4,7,7,1),cluster(.57,.97,-1,1.7,2,[.57,.43])));
  fork(white,strip('stag-low-flute',[[219,123],[240,138],[262,144],[287,143],[307,137],[311,131],[307,129]],taper(5,7,5,1),cluster(.55,.95,1,1.75,2,[.58,.42])));
  const arch=strip('stag-arch',[[203,106],[225,110],[248,105],[266,92],[281,73],[299,56],[320,51],[335,63],[338,83],[330,102],[328,114]],[[0,5],[.13,9],[.35,4],[.51,4],[.71,5],[.86,10],[.96,8],[1,.5]],cluster(.76,.97,-1,1.55,2,[.61,.39]));
  fork(arch,strip('stag-inturned-point',[[312,52],[306,58],[298,65],[293,69]],taper(3,4,4,2),cluster(.14,.55,1,1.28,1,[.63,.37]),scroll(7,-1,.55)));
  fork(arch,strip('stag-downturn',[[330,103],[335,116],[329,134],[318,147],[318,156]],taper(5,5,3,2.8),fold(.35,.12,1),scroll(8,-1,.70)));
  return mantle(white,arch);
}

function parchment(){
  const top=strip('parchment-high-arc',[[203,105],[222,104],[244,88],[265,78],[282,77],[297,84],[300,98]],[[0,3],[.26,5],[.57,3.1],[.85,3.9],[1,2.9]],cluster(.33,.54,-1,1.35,1,[.61,.39]),scroll(11,1,.85));
  fork(top,strip('parchment-high-lining',[[220,105],[240,101],[259,92],[278,88],[292,93]],taper(2.7,6,4),fold(.11,.12,-1),cluster(.43,.78,-1,1.0,1,[.43,.57])));
  fork(top,strip('parchment-upper-panel',[[219,104],[238,101],[258,96],[280,93],[294,99],[293,108]],taper(2,7,9,1.5),fold(.07,.10,-1),cluster(.49,.86,1,1.02,1,[.53,.47]),fold(.82,.15,1)));
  fork(top,strip('parchment-dusky-tuft',[[291,80],[299,85],[305,97],[302,108],[294,112],[287,109]],taper(2,4.6,5,1),cluster(.37,.90,-1,1.45,1,[.44,.32,.24])));
  const low=strip('parchment-lower-arc',[[201,114],[219,119],[240,124],[257,132],[261,144],[255,150]],taper(3.3,5,4,2.8),fold(.36,.11,-1),cluster(.43,.68,-1,1.2,1,[.65,.35]),fold(.75,.12,1),scroll(8.5,1,.78));
  fork(low,strip('parchment-low-panel',[[219,119],[231,122],[242,131],[250,136],[254,143],[251,147]],taper(2,6,6,.9),fold(.08,.12,-1),cluster(.45,.80,1,1.15,1,[.62,.38]),fold(.84,.15,-1)));
  fork(low,strip('parchment-low-fringe',[[254,129],[261,135],[265,143],[263,152],[258,156]],taper(1.5,3.5,4,1),cluster(.45,.93,-1,1.45,1,[.60,.40])));
  return mantle(top,low);
}

function tassels(){
  const sheet=strip('tassels-broad-cloth',[[204,112],[224,117],[245,114],[265,103],[278,92],[291,85],[300,87]],[[0,5],[.15,13],[.42,18],[.72,21],[.9,14],[1,4]],fold(.07,.095,-1),cluster(.36,.66,-1,.72,1,[.54,.46]));
  fork(sheet,strip('tassels-hem',[[215,117],[234,132],[259,137],[287,132],[306,124]],taper(7,11,13),cluster(.5,.84,-1,.74,1,[.58,.42])));
  const edge=strip('tassels-arched-edge',[[205,108],[223,107],[240,96],[248,77],[258,61],[273,55],[285,59],[298,74],[302,95],[300,113]],[[0,5],[.17,8],[.35,3],[.56,6],[.68,7],[.84,4],[1,4]],cluster(.04,.22,1,1.15,1,[.37,.36,.27]),cluster(.51,.74,1,1.35,1,[.48,.52]));
  const outer=strip('tassels-outer-flank',[[301,102],[309,113],[312,126],[308,138],[303,152],[306,168],[312,180],[313,191],[309,201],[299,213],[300,222],[305,225]],[[0,3],[.18,10],[.39,5],[.52,3],[.68,9],[.79,12],[.87,6],[.94,6],[1,.75]],cluster(.105,.34,-1,1.54,2,[.56,.44]),cluster(.59,.85,1,1.46,2,[.57,.43]),fold(.81,.09,1),cluster(.89,.96,-1,1.6,1,[.57,.43]));
  fork(outer,strip('tassels-lateral-curl',[[304,154],[314,153],[321,158],[321,164]],taper(2,3.2,2,1.7),scroll(5,1,.71)));
  const second=strip('tassels-second-shoulder',[[227,106],[246,108],[264,99],[282,96],[301,102],[309,113],[308,124],[300,130]],[[0,4],[.26,4],[.51,3.5],[.74,4],[.90,7],[1,2]],cluster(.05,.28,1,1.16,1,[.4,.6]),cluster(.73,.96,-1,1.45,1,[.57,.43]));
  fork(second,strip('tassels-downward-dagge',[[308,115],[304,127],[295,137],[295,145],[299,150]],taper(5,9,7,1),cluster(.37,.94,1,1.1,2,[.56,.44])));
  fork(edge,second);
  fork(edge,outer);
  return mantle(sheet,edge);
}
const works={lion:lion(),stirling:stirling(),stag:stag(),parchment:parchment(),tassels:tassels()};
for(const item of Object.values(works))model.walk(item,el=>{
  if(model.clustersUsed(el.events)>.600001)throw Error('Too little bare spine on '+el.id);
  el.events.forEach((ev,i)=>ev.id=el.id+'-'+ev.type+'-'+(i+1));
});
fs.writeFileSync(__dirname+'/presets.json',JSON.stringify(works,null,1)+'\n');
