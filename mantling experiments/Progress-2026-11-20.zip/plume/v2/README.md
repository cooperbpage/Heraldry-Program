# Studies in Mantling

Open Mantling-v2.html in a browser that runs JavaScript, or open the hosted editor in Safari. The HTML embeds the typefaces, renderer, controls and five editable studies. The shield occupies 100 of the sheet’s 400 horizontal units. Each mark drawn on either side is reflected about the helm.

## Working on a drawing

Reset clears the drawing. Select **Compose on draw** and draw one, two or three main sweeps. **Reseed** keeps their courses and recomposes the foliage. To preserve generated ornament across reseeds, select and change its mark. Undo and redo step through architectural changes, including reset and reseed. Rendering, smoothing and guide settings stay as selected. Your last design is stored in the current browser when local storage is available. SVG export saves an illustration. The five original editable models are in presets.json.

| Instrument | Gesture |
| --- | --- |
| Sweep | Draw from root to tip. Choose a stem and Redraw selected to replace its course. Smoothing applies to subsequent strokes. |
| Bracket cluster | Drag along one edge. Select the mark to adjust the bracket, scale, depth and relative shares of the leaflets. |
| Fork | Start on a stem and sweep away. The child grows behind its parent. Its own events can be edited through the Stem list. |
| Pinch width | Spread two fingers across a stem to set its full width, or pull across the spine with one finger. The perpendicular distance sets the local half-width. |
| Volute by eye | Drag from a station toward the centre of the desired coil. The eye is projected onto the compatible direction so the volute leaves tangentially. Adjust turns, radius, decay or hand below the sheet. |
| Fold | Drag diagonally across the strip. The starting edge and length determine how the lip crosses it. Past the fold the exposed face changes. |

Marks can be selected by touch or by choosing a stem and event from the lists. The percentage beside a mark denotes distance along the stem. A cluster's list entry uses the midpoint of its bracket.

## Embedding

geometry.js and model.js expose Geometry and MantlingModel in a browser, or CommonJS exports under Node. geometry.d.ts describes the principal rendering API. Geometry.fit(points, smoothing) returns cubic Bézier segments; Geometry.render(design, layers) returns SVG markup in a 400 × 370 coordinate frame. Insert the returned markup in an SVG before the helmet and shield. Set each boolean appearance option explicitly when rendering a particular finish. Pass a deep copy to the editor when the caller owns the original design.

The event station is a normalized arc length. Width knots are pairs of station and half-width in sheet units. A branch contains another complete strip. Its departure angle is measured in degrees relative to the parent’s tangent. A volute's hand is signed; its radius is in sheet units. Cluster size scales with local width; splits are relative weights. The union of ranges carrying clusters may occupy at most 60 percent of any stem. The prescribed thresholds and symmetries are drawing conventions for this experiment.

Build with Python 3 using `python build.py` in the unpacked source directory. Both WOFF files belong beside build.py. Run `node proofs/geometry-checks.cjs` for the geometry checks. Verification-v2.zip includes the browser comparison sheets, the independent critique, reference crops, stage snapshots, and offline proof renderers. Source research is in research.md.
