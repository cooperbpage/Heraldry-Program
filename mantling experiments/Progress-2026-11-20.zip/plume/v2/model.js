/* Design editing and seeded composition. Both the editor and renderer consume
 * the same JSON. Descendants retain their authored spine and attachment. */
(function(root, create) {
  const api = create(typeof module === 'object' ? require('./geometry.js') : root.Geometry);
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.MantlingModel = api;
})(globalThis, function(G) {
  'use strict';
  const clamp=(n,lo,hi)=>Math.max(lo,Math.min(hi,n));
  const copy=o=>JSON.parse(JSON.stringify(o));
  const distance=(a,b)=>Math.hypot(a[0]-b[0],a[1]-b[1]);
  function walk(doc, fn) {
    function visit(el, parent, attachment) {
      fn(el,parent,attachment);
      for(const e of el.events) if(e.type==='branch') visit(e.child,el,e);
    }
    doc.roots.forEach(el=>visit(el,null,null));
  }
  function clustersUsed(events) {
    const ranges=events.filter(e=>e.type==='cluster').map(e=>[e.t0,e.t1]).sort((a,b)=>a[0]-b[0]);
    let covered=0, end=0;
    for(const [a,b] of ranges){covered+=Math.max(0,b-Math.max(a,end));end=Math.max(b,end);}
    return covered;
  }
  function snapshotHistory() {
    const past=[],future=[];
    return {
      record(doc){past.push(copy(doc));if(past.length>60)past.shift();future.length=0;},
      undo(doc){if(!past.length)return doc;future.push(copy(doc));return past.pop();},
      redo(doc){if(!future.length)return doc;past.push(copy(doc));return future.pop();},
      get canUndo(){return past.length>0;},get canRedo(){return future.length>0;}
    };
  }
  function randomStream(seed) {
    let state=seed|0;
    return function(){state+=0x6D2B79F5;let n=Math.imul(state^(state>>>15),1|state);
      n^=n+Math.imul(n^(n>>>7),61|n);return ((n^(n>>>14))>>>0)/4294967296;};
  }
  function newStrip(id, spine, width=9){
    return {id, spine, width:[[0,width*.56],[.24,width],[.70,width*.79],[1,.25]],events:[]};
  }
  function framePoint(f,along,across){
    return [f.p[0]+along*f.tangent[0]+across*f.normal[0],f.p[1]+along*f.tangent[1]+across*f.normal[1]];
  }
  function departure(parentSpine,t,childSpine){
    const a=G.frame(parentSpine,t).tangent,b=G.frame(childSpine,0).tangent;
    return Math.atan2(a[0]*b[1]-a[1]*b[0],a[0]*b[0]+a[1]*b[1])*180/Math.PI;
  }
  function decorate(doc,seed) {
    const result=copy(doc), rand=randomStream(seed);
    const between=(a,b)=>a+(b-a)*rand();
    const side=()=>rand()<.5?-1:1;
    function purge(el) {
      el.events=el.events.filter(e=>!e.generated);
      for(const e of el.events)if(e.type==='branch')purge(e.child);
    }
    result.roots.forEach(purge);
    const used=new Set();
    walk(result,el=>{used.add(el.id);el.events.forEach(e=>used.add(e.id));});
    let serial=0;
    function id(){let key;do{key='seed-'+(seed>>>0).toString(36)+'-'+(++serial);}while(used.has(key));used.add(key);return key;}
    const mark=(el,e)=>{e.id=id();e.generated=true;el.events.push(e);return e;};
    function cluster(el,t0,t1,s) {
      const e={type:'cluster',t0,t1,side:s,size:between(.9,1.8),depth:rand()<.45?2:1,splits:[between(.2,.36),between(.35,.52),between(.17,.29)]};
      if(clustersUsed([...el.events,e])<=.6000001)mark(el,e);
    }
    function fold(el,t,s){
      if(!el.events.some(e=>e.type==='fold'&&Math.abs(e.t-t)<.15))mark(el,{type:'fold',t,length:between(.065,.13),edge:s});
    }
    result.roots.forEach((el,index)=>{
      const s=side(), first=between(.12,.30), second=between(.64,.77);
      cluster(el,first,first+between(.12,.22),s);
      cluster(el,second,Math.min(.97,second+between(.12,.20)),-s);
      fold(el,between(.33,.53),s);
      const reach=Array.from({length:17},(_,i)=>G.frame(el.spine,i/16).p);
      const length=reach.slice(1).reduce((sum,p,i)=>sum+distance(p,reach[i]),0);
      const span=clamp(length*.24,8,36);
      const forks=length>90&&rand()>.48?2:1;
      for(let j=0;j<forks;j++){
        const t=j?between(.60,.75):between(.20,.45), f=G.frame(el.spine,t);
        const sign=j?-s:s, w=G.widthAt(el,t);
        const along=span*between(.75,1.45), sweep=sign*span*between(.65,1.35);
        const child=newStrip(id(),G.fit([f.p,framePoint(f,along*.32,sweep*.17),framePoint(f,along*.69,sweep*.68),framePoint(f,along,sweep),framePoint(f,along*1.22,sweep*.92)],.30),clamp(w*.69,2,10));
        mark(el,{type:'branch',t,side:sign,departure:departure(el.spine,t,child.spine),child});
        cluster(child,.42,between(.75,.92),-sign);
        if(j===0)fold(child,between(.16,.32),sign);
        if(j||rand()<.5){
          const radius=span*between(.23,.43);
          child.width[child.width.length-1][1]=Math.min(radius*.26,child.width[1][1]);
          mark(child,{type:'volute',t:1,turns:between(.66,1.03),hand:-sign,radius,tightening:between(.21,.34)});
        }
      }
      mark(el,{type:'volute',t:G.widthAt(el,1)>2&&rand()>.5?1:between(.67,.88),turns:between(.76,1.13),hand:side(),radius:clamp(span*between(.39,.75),4,24),tightening:between(.20,.33)});
    });
    return result;
  }
  // An edited generated branch survives reseeding along with its attachment.
  function keep(doc,el,event){
    if(event)delete event.generated;
    const parents=new Map();walk(doc,(node,parent,attachment)=>parents.set(node,{parent,attachment}));
    while(el){const item=parents.get(el);if(!item)break;if(item.attachment)delete item.attachment.generated;el=item.parent;}
  }
  return {clamp,copy,distance,walk,clustersUsed,snapshotHistory,newStrip,departure,decorate,keep};
});
