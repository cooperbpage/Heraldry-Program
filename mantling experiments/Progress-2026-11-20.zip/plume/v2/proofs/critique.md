# Visual critique of the second mantling experiment

## Reference criteria

I examined the five reattached achievements independently of the builders. Titles below describe the pictures.

- **Lion crest.** White cloth spreads in fans behind a low, broad sweep of red. The two upright scrolls have eyes through which the page is visible. A red interval between white lobes can also be an overlap, so color alone cannot establish a hole.
- **Earl of Stirling.** Heavy, upright lobes grow out of a mass of cloth gathered at the helm. Short dark edges indicate overlap. The smaller curls play against this mass.
- **Stag crest.** The pale, radiating dagges taper at different depths under two hooded red arches. The larger openings have irregular boundaries, and the curled tips return into those openings.
- **Parchment achievement.** Thin arcs, sparse dagging, and small, unequal returns suit the intimate scale. Much of the apparently pale area inside the long outer arc is represented cloth, bounded by the lower sweep and marked internally.
- **Tasselled achievement.** The two great red arcs enclose broad white faces. The inner curves are cloth folds. Only a few small outside loops admit the parchment. The pendent red figures have broad heads and thin ties.

I judge a true eye by seeing its background through it. Where a broad panel of white cloth occupies the same space, its boundary, edge thickness and interior strokes must establish its material. The optional rendering layers may clarify an underlying form, but flat color alone should identify its silhouette, dominant stems, and openings.

## Isolated volute

The preliminary Inkscape rendering clipped the lowest contour. I requested a wider frame and reviewed the uncropped replacement. The outer sweep is continuous; its greatest mass is carried over the brow of the curl, and it diminishes to a red point that turns back into the eye. The bounded ivory crescent is lining. A distinct open space survives between it and the incoming red stem. A subtle central stroke follows the taper. The revised shape passes the silhouette criterion.

## Isolated folded stem and bracketed foliage

The isolated stem's first Inkscape proof shows a structurally legible face change. An oblique red lip passes over the lower margin and the ivory face continues for a substantial distance beyond the pinch. The empty edge below the cluster also survives. I held the gate because the upright leaflets on the upper edge have straight sides and abrupt, squared flag-like shoulders. Their outer points barely turn into the air between the leaves. I requested bowed shoulders, a more pronounced terminal return, and smoother tone across adjoining bands.

In the revised isolated proof, the two largest leaflets rise on convex shoulders and their tips turn forward over open notches. The red lip still crosses the narrowing stem before the lining opens out. The isolated stem passes. The aft end of the cluster retains a short flat shelf, worth watching when leaves are seen together at phone size.

## First full-composition review

Examined all five side-by-side browser PNGs in `round-01`. The first three defects went back to the builders before the next round.

1. On the stag and lion studies, the ivory fans resolve into about three widely separated pointed slats. The references have a mass of overlapping flutes, with staggered, divided ends. Bring their origins together, vary the direction of the flutes and cut meaningful clusters into the outer edges.
2. The lion's upper tendrils read as bare question marks and the lower outer return as a thin C. The reference has a spreading upper crest and layered red returns around openings. Broaden the turning brows and give the upper and lower scrolls distinct counterbranches.
3. Stirling has become a red crossbar over two nearly rectangular windows. The reference rises in separate red masses over a deep gathered pale field, then returns in thick hooks by the crown. Reorient the red stems and build pale drapery behind them.
4. The parchment's upper and lower arcs change direction at visible corners. Their interiors are nearly empty, while the original carries pale, ink-marked material into the open sweep.
5. The two tasselled-study drops split into little bell-shaped terminals with white spikes. The reference places an irregular broad red leaf head above a separate pale, lobed continuation.

## Second full-composition review

The five browser sheets in `round-02` include a legible enlarged detail. The lion now has separate upper and lower scrolls and an overlapping red fore-band. Stirling has a deeper ivory body and a descending hook. The broad stag and lion fans have gained material, although much of their new foliage disappears under its neighbours. The former hard corners in the parchment arcs have softened. The next three changes were issued in rank order.

1. The stag fan still ends in broad, smooth spear points with tiny triangular lobes along the lowest edge. The numerous slender folds in the reference remain separately visible nearly to their divided ends. Stagger and angle the flutes, concentrating deeper brackets along the visible outer edge. The lion needs the same treatment.
2. In the tasselled study a single U passes into a thin S with two bell-shaped pockets. The second looping shoulder, broad red pendent leaf heads, and substantial pale terminal on the original are missing. Add the second looping branch, divide the width of the heads into larger leaflets, and expand the pale continuation.
3. The parchment's red arcs terminate in bare compass hooks, enclosing blank paper above thin ivory strips. Fill part of both tiers with broader pale cloth, with a few short internal cuts, and widen the dark terminal tufts. Keep the air between tiers.
4. The Stirling study has several red horns pointing in unison. The bottom curl almost vanishes against the upper shield corner. Reverse or fan the horns and give the low return more side clearance.
5. In the lion study, the red at the centre forms a nearly untouched band. The upper eye also carries a slender secondary hook where the source has a broad divided red crest. Both terminals need visible, well-separated lobe heads.
