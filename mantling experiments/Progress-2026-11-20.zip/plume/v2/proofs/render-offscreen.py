"""Run inside PythonQt via render-offscreen.sh. Blink renders each SVG into a PNG."""
import base64
import json
import os
import tempfile
from pathlib import Path

import qt
import slicer

queue = [Path(p) for p in json.loads(os.environ["MANTLING_PROOF_INPUTS"])]
widget = slicer.qSlicerWebWidget()
temp = tempfile.TemporaryDirectory()
page_file = Path(temp.name) / 'proof.html'
current = None
attempts = 0

def next_image():
    global current, attempts
    if not queue:
        slicer.util.exit()
        return
    current = queue.pop(0)
    attempts = 0
    encoded = base64.b64encode(current.read_bytes()).decode()
    page_file.write_text("""<!doctype html><meta charset="utf-8"><canvas></canvas><script>
      window.result = '';
      const image = new Image();
      image.onload = function () {
        try {
          const canvas = document.querySelector('canvas');
          canvas.width=image.naturalWidth; canvas.height=image.naturalHeight;
          canvas.getContext('2d').drawImage(image,0,0);
          window.result=canvas.toDataURL('image/png');
        } catch (err) {window.result='ERROR: '+err.message;}
      };
      image.onerror=function(){window.result='ERROR: SVG load failed';};
      image.src='data:image/svg+xml;base64,""" + encoded + """';
    </script>""")
    # Distinct queries force a fresh navigation even when one renderer handles a batch.
    widget.url=page_file.as_uri()+'?proof='+str(len(queue))
    qt.QTimer.singleShot(240, poll)

def poll():
    widget.evalJS("window.result || ''")

def receive(script, result):
    global attempts
    if script != "window.result || ''":
        return
    if result.startswith('data:image/png;base64,'):
        dest = current.with_name(current.stem+'-browser.png')
        data=base64.b64decode(result.split(',',1)[1], validate=True)
        if not data.startswith(b'\x89PNG\r\n\x1a\n'):
            raise RuntimeError('Unexpected browser result')
        dest.write_bytes(data)
        print('PNG',dest,len(data),flush=True)
        qt.QTimer.singleShot(20,next_image)
    elif result.startswith('ERROR:') or attempts>200:
        print('Browser rendering failed:', current,result[:150],flush=True)
        slicer.util.exit(1)
    else:
        attempts+=1
        qt.QTimer.singleShot(100,poll)

widget.connect('evalResult(QString,QString)',receive)
next_image()
