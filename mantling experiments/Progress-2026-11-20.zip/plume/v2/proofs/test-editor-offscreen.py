"""Run in Slicer's PythonQt with MANTLING_HTML pointing to the built editor."""
import os
from pathlib import Path
import qt
import slicer

widget = slicer.qSlicerWebWidget()
widget.resize(390,844)
widget.url = Path(os.environ['MANTLING_HTML']).resolve().as_uri()
script = Path(__file__).with_name('editor-check.js').read_text().strip()
def receive(command, result):
    print(result, flush=True)
    slicer.util.exit(0 if result.startswith('PASS') else 1)
widget.connect('evalResult(QString,QString)',receive)
qt.QTimer.singleShot(3500,lambda:widget.evalJS('(()=>{try{return '+script+'}catch(e){return e.stack}})()'))
qt.QTimer.singleShot(75000,lambda:slicer.util.exit(1))
