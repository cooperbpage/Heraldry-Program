"""Rebuild the reference details from the five project attachments; run with their directory as argument."""
import json
import sys
from pathlib import Path
from PIL import Image

out = Path(__file__).resolve().parent / 'references'
src = Path(sys.argv[1])
# x0,y0,x1,y1 in original pixels; preserve every pixel in these rectangles.
records = {
 'lion': ('IMG_8978(1).png', 'Lion crest and white supporters', (18,12,483,299), (248,18,483,227)),
 'stirling': ('IMG_8974(1).jpeg', 'Earl of Stirling', (36,18,402,325), (206,61,411,270)),
 'stag': ('IMG_8977(1).jpeg', 'Stag crest and supporters', (26,12,504,325), (256,49,506,267)),
 'parchment': ('IMG_8971(1).png', 'Parchment with greyhound and lion', (0,7,215,153), (107,28,214,115)),
 'tassels': ('IMG_8976(1).png', 'Ram crest and tasselled cords', (0,2,500,437), (248,47,500,372))
}
out.mkdir(exist_ok=True)
manifest = []
for key, (name, title, crop, detail) in records.items():
    with Image.open(src/name) as im:
        im = im.convert('RGB')
        im.crop(crop).save(out/(key+'.png'), optimize=True)
        im.crop(detail).save(out/(key+'-detail.png'), optimize=True)
        manifest.append(dict(key=key,title=title,source=name,sourceSize=im.size,context=crop,detail=detail))
(out/'sources.json').write_text(json.dumps(manifest,indent=2)+'\n')
