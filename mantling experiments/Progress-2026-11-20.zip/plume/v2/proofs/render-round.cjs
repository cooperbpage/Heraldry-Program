/* node render-round.cjs <round-01|round-02|round-03|final>
 * Uses installed Playwright and Chromium. CHROMIUM_PATH may select an executable.
 * Each output folder preserves the exact generator and parameters it used.
 * For an earlier state: node render-round.cjs round-01 --frozen
 */
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const round = process.argv[2];
if (!['round-01','round-02','round-03','final'].includes(round)) throw Error('Choose a numbered round or final.');
const frozen = process.argv.includes('--frozen');
const out = path.join(__dirname,round), base=path.dirname(__dirname), refDir=path.join(__dirname,'references');
const {chromium} = require(require.resolve('playwright', {paths:[__dirname,process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES || __dirname]}));
const records = JSON.parse(fs.readFileSync(path.join(refDir,'sources.json')));
const pngURL = p => 'data:image/png;base64,'+fs.readFileSync(p).toString('base64');
const hash = p => crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
(async () => {
  fs.mkdirSync(out,{recursive:true});
  if(!frozen) {
    for(const f of ['geometry.js','presets.json']) fs.copyFileSync(path.join(base,f),path.join(out,f));
    fs.copyFileSync(path.join(base,'helmet.svg'), path.join(out,'frame.svg'));
  }
  const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
  try {
    const page=await browser.newPage({viewport:{width:1040,height:600},deviceScaleFactor:1});
    const model=JSON.parse(fs.readFileSync(path.join(out,'presets.json')));
    const helm=fs.readFileSync(path.join(out,'frame.svg'),'utf8');
    const manifest={round,chromium:browser.version(),deviceScaleFactor:1,viewport:[1040,600],generatorHash:hash(path.join(out,'geometry.js')),parametersHash:hash(path.join(out,'presets.json')),references:[]};
    for(const r of records){
      const full=pngURL(path.join(refDir,r.key+'.png')),detail=pngURL(path.join(refDir,r.key+'-detail.png'));
      await page.setContent(`<style>
        *{box-sizing:border-box}body{margin:0;background:#fffdf7;color:#282020;font:17px Georgia,serif}
        main{width:1040px;padding:15px 18px 14px} h1{font-size:21px;font-weight:normal;margin:0 0 9px}
        section{display:grid;grid-template-columns:1fr 1fr;gap:18px}.art{height:326px;width:100%;object-fit:contain;display:block}
        h2{margin:2px 0 3px;font-size:14px;font-weight:normal;font-style:italic}
        section+section{margin-top:6px;border-top:1px solid #cfc6b7;padding-top:2px}
        .detail{height:174px;width:100%;display:block;object-fit:contain}svg{overflow:hidden}
        </style><main><h1>${r.title} · ${round}</h1><section><div><h2>Reference surrounding the helm</h2><img class="art" src="${full}"></div>
        <div><h2>Generated achievement</h2><svg class="art" id="whole" viewBox="0 0 400 300"></svg></div></section>
        <section><div><h2>Reference detail</h2><img class="detail" src="${detail}"></div>
        <div><h2>Right-hand construction</h2><svg class="detail" id="detail" viewBox="196 38 198 195"></svg></div></section></main>`);
      await page.addScriptTag({path:path.join(out,'geometry.js')});
      await page.evaluate(({m,h})=>{
        for(const id of ['whole','detail']) {
          const node=document.getElementById(id);
          node.innerHTML=window.Geometry.render(m,{fill:true,line:true,rib:true,hatch:false,shade:true,idPrefix:id})+h;
        }
      },{m:model[r.key],h:helm});
      await page.evaluate(async()=>await Promise.all([...document.images].map(i=>i.decode())));
      await page.locator('main').screenshot({path:path.join(out,r.key+'.png')});
      manifest.references.push({key:r.key,proof:r.key+'.png',source:r.source});
    }
    fs.writeFileSync(path.join(out,'manifest.json'),JSON.stringify(manifest,null,2)+'\n');
  } finally { await browser.close(); }
})().catch(e=>{console.error(e);process.exitCode=1});
