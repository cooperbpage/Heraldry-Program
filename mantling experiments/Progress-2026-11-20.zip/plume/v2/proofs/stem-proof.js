'use strict';
const fs=require('fs'),G=require('../geometry.js');
const spine=G.fit([[64,170],[82,159],[114,139],[147,126],[179,122],[200,111],[228,91]],.45);
const e={id:'stem',spine,width:[[0,2.4],[.17,9.6],[.42,15],[.66,9.3],[.84,11.8],[1,3]],events:[
 {type:'cluster',t0:.19,t1:.51,side:-1,size:1.65,depth:2,splits:[.46,.32,.22]},
 {type:'fold',t:.65,length:.20,edge:1}
]};
const svg='<svg xmlns="http://www.w3.org/2000/svg" width="720" height="470" viewBox="48 70 195 121"><rect x="0" y="0" width="400" height="370" fill="#faf7ee"/>'+G.render({roots:[e],mirror:false},{fill:true,line:true,rib:true,shade:true})+'</svg>';
fs.writeFileSync(__dirname+'/02-stem.svg',svg);
