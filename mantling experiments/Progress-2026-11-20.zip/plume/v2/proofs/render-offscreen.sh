#!/bin/sh
set -eu
here=$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd)
MANTLING_PROOF_INPUTS=$(python3 -c 'import sys,json,pathlib;print(json.dumps([str(pathlib.Path(p).resolve(strict=True)) for p in sys.argv[1:]]))' "$@")
export MANTLING_PROOF_INPUTS
export QT_QPA_PLATFORM=offscreen
export QT_QPA_PLATFORM_PLUGIN_PATH="${QT_QPA_PLATFORM_PLUGIN_PATH:-/usr/lib/x86_64-linux-gnu/qt5/plugins/platforms}"
export QTWEBENGINE_CHROMIUM_FLAGS=--disable-gpu
exec "${SLICER_BIN:-/opt/slicer/5.10.0/Slicer}" --no-main-window --disable-modules --python-script "$here/render-offscreen.py"
