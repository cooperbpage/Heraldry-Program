/* Alternate raster verifier for environments that cannot start Chromium.
 * Node builds the SVG with the exact production engine. Inkscape rasterizes it.
 * node render-vector.cjs <round-01|round-02|round-03|final> [--frozen]
 */
'use strict';
const fs=require('node:fs'), path=require('node:path'), cp=require('node:child_process');
const hash=p=>require('node:crypto').createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const round=process.argv[2], frozen=process.argv.includes('--frozen'), base=path.dirname(__dirname);
if(!['round-01','round-02','round-03','final'].includes(round))throw Error('Unknown round');
const out=path.join(__dirname,round), refs=path.join(__dirname,'references');
fs.mkdirSync(out,{recursive:true});
if(!frozen){
 for(const f of ['geometry.js','presets.json'])fs.copyFileSync(path.join(base,f),path.join(out,f));
 fs.copyFileSync(path.join(base,'helmet.svg'),path.join(out,'frame.svg'));
}
const records=JSON.parse(fs.readFileSync(path.join(refs,'sources.json'))), model=require(path.join(out,'presets.json'));
const G=require(path.join(out,'geometry.js')), frame=fs.readFileSync(path.join(out,'frame.svg'),'utf8');
const svgFor=(r,id,v,x,y,w,h)=>`<svg viewBox="${v}" x="${x}" y="${y}" width="${w}" height="${h}"><defs><clipPath id="clip-${id}"><rect x="${v.split(' ')[0]}" y="${v.split(' ')[1]}" width="${v.split(' ')[2]}" height="${v.split(' ')[3]}"/></clipPath></defs><g clip-path="url(#clip-${id})">${G.render(model[r.key],{idPrefix:id,fill:true,line:true,rib:true,hatch:false,shade:true})}${frame}</g></svg>`;
const esc=s=>String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;');
const label=(s,x,y,size)=>`<text x="${x}" y="${y}" font-size="${size}" font-family="serif" fill="#302b29">${esc(s)}</text>`;
const embed=(f,x,y,w,h)=>`<image x="${x}" y="${y}" width="${w}" height="${h}" xlink:href="data:image/png;base64,${fs.readFileSync(path.join(refs,f)).toString('base64')}"/>`;
const ink=cp.execFileSync('inkscape',['--version'],{encoding:'utf8'}).trim();
const manifest={round,renderer:ink,geometry:hash(path.join(out,'geometry.js')),model:hash(path.join(out,'presets.json')),proofs:[]};
for(const r of records){
 const proof='<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="1040" height="800">'
    +'<rect width="1040" height="800" fill="#fffdf7"/>'
    +label(r.title+' · '+round,18,28,21)+label('Reference surrounding the helm',18,55,14)+label('Generated achievement',535,55,14)
    +embed(r.key+'.png',16,61,499,320)+svgFor(r,'full','0 0 400 300',529,61,499,320)
    +'<path d="M18 390H1022" stroke="#d0c8bb" stroke-width="1"/>'
    +label('Reference detail',18,410,14)+label('Right-hand construction',535,410,14)
    +embed(r.key+'-detail.png',16,418,499,362)+svgFor(r,'detail','196 38 198 195',529,418,499,362)+'</svg>';
 const src=path.join(out,r.key+'.svg'), dest=path.join(out,r.key+'.png');
 fs.writeFileSync(src,proof);
 cp.execFileSync('inkscape',[src,'--export-filename='+dest],{stdio:['ignore','ignore','ignore']});

 manifest.proofs.push(r.key+'.png');
}
fs.writeFileSync(path.join(out,'manifest.json'),JSON.stringify(manifest,null,2)+'\n');
