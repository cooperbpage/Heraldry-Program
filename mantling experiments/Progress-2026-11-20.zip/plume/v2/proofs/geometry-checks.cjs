/* Regression checks for invariants that screenshots alone cannot establish. */
const assert = require('node:assert/strict');
const G = require('../geometry.js');

const stroke = Array.from({length:181},(_,i)=>[i, 17*Math.sin(i/25)+1.2*Math.sin(i*2.1)]);
const loose = G.fit(stroke,1), tight = G.fit(stroke,0);
assert(loose.length<=12 && loose.length<tight.length/3);
assert.deepEqual(loose[0][0],stroke[0]);
assert.deepEqual(loose.at(-1)[3],stroke.at(-1));

function derivative(segment,end,order) {
  const [a,b,c,d] = segment;
  if(order===1) return a.map((_,k)=>3*(end?d[k]-c[k]:b[k]-a[k]));
  return a.map((_,k)=>6*(end?d[k]-2*c[k]+b[k]:c[k]-2*b[k]+a[k]));
}
function curvature(segment,end) {
  const v=derivative(segment,end,1),a=derivative(segment,end,2);
  return (v[0]*a[1]-v[1]*a[0])/(Math.hypot(...v)**3);
}
for(let i=1;i<loose.length;i++) {
  const a=loose[i-1],b=loose[i],v=derivative(a,true,1),w=derivative(b,false,1);
  assert(Math.abs((v[0]*w[1]-v[1]*w[0])/(Math.hypot(...v)*Math.hypot(...w)))<1e-9);
  assert(v[0]*w[0]+v[1]*w[1]>0);
  assert(Math.abs(curvature(a,true)-curvature(b,false))<1e-9);
}
const spine=G.fit([[90,140],[120,138],[140,125],[160,115]]);
const strip={id:'stem',spine,width:[[0,4],[.5,11],[1,3.1]],events:[]};
const clusters=[
  {type:'cluster',t0:.05,t1:.39,side:1},
  {type:'cluster',t0:.23,t1:.5,side:-1},
  {type:'cluster',t0:.62,t1:.99,side:-1}
];
const accepted=G.eventGeometry({...strip,events:clusters}).clusters;
let end=0,sum=0;
for(const {t0,t1} of accepted.sort((a,b)=>a.t0-b.t0)){sum+=Math.max(0,t1-Math.max(end,t0));end=Math.max(end,t1);}
assert(sum>.599 && sum<=.600001);
const f=G.frame(spine,.7),v={type:'volute',t:.7,turns:.92,hand:-1,radius:17,tightening:.24};
const eye=G.eye(spine,v);
let previous=Infinity,prevStep=Infinity,last;
for(let j=0;j<=100;j++) {
  const q=G.spiralFrame(f,j*.05,v.tightening,v.radius,v.hand);
  const r=Math.hypot(q.p[0]-eye[0],q.p[1]-eye[1]);assert(r<previous);previous=r;
  if(!j){assert.deepEqual(q.p,f.p);assert.deepEqual(q.tangent,f.tangent);}
  if(last){
    const ds=Math.hypot(q.p[0]-last.p[0],q.p[1]-last.p[1]);
    assert(ds<prevStep);prevStep=ds; // equal angle over decreasing length
  }
  last=q;
}
const children=[{...strip,id:'early'},{...strip,id:'late'}];
const doc={mirror:true,roots:[{...strip,events:[...clusters,v,{type:'fold',t:.57,edge:1,length:.14},...children.map((child,i)=>({type:'branch',t:i?.73:.22,child,side:1}))]}]};
assert.deepEqual(G.placed(doc).map(p=>p.back),[false,false,true]);
const layers=['fill','line','rib','shade','hatch'];
for(let mask=0;mask<32;mask++){
  const settings=Object.fromEntries(layers.map((x,i)=>[x,!!(mask&(1<<i))]));
  const svg=G.render(doc,settings);
  assert(!/NaN|Infinity|undefined/.test(svg));assert.equal(!!svg,!!mask);
  if(settings.shade) assert(svg.includes('clip-path=') && svg.includes('linearGradient'));
}
console.log('Passed: sparse smooth fit, geometric continuity, bare length, spiral tangency and increasing curvature, face inheritance, 32 layer combinations.');
