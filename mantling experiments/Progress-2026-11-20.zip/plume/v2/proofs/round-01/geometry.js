/* Mantling geometry v2. World units are SVG units. Times are normalized arc length. */
(function(root,factory){
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  else root.Geometry=api;
})(typeof globalThis==='undefined'?this:globalThis,function(){
'use strict';
const PI=Math.PI, TAU=2*PI, clamp=(a,l,h)=>Math.max(l,Math.min(h,a));
const mix=(a,b,t)=>a+(b-a)*t, lerp=(a,b,t)=>[mix(a[0],b[0],t),mix(a[1],b[1],t)];
const dist=(a,b)=>Math.hypot(a[0]-b[0],a[1]-b[1]);
const norm=(x,y)=>{const l=Math.hypot(x,y)||1;return [x/l,y/l]};
const okay=p=>Array.isArray(p)&&Number.isFinite(p[0])&&Number.isFinite(p[1]);
const number=(v,fallback)=>Number.isFinite(v)?v:fallback;
const fmt=v=>String(+v.toFixed(3)), xy=p=>fmt(p[0])+','+fmt(p[1]);
const add=(p,t,n,x,y)=>[p[0]+t[0]*x+n[0]*y,p[1]+t[1]*x+n[1]*y];
const smooth=x=>{x=clamp(x,0,1);return x*x*(3-2*x)};
function measurePoly(points){
  const l=[0];for(let i=1;i<points.length;i++)l.push(l[i-1]+dist(points[i],points[i-1]));
  const length=l[l.length-1]||0;
  function at(s){
    if(s<=0||!length)return points[0];
    if(s>=length)return points[points.length-1];
    let a=0,b=l.length-1;while(b-a>1){const m=(a+b)>>1;if(l[m]<s)a=m;else b=m;}
    return lerp(points[a],points[b],(s-l[a])/(l[b]-l[a]));
  }
  return {length,at};
}
function pointSegment(p,a,b){
 const dx=b[0]-a[0],dy=b[1]-a[1],den=dx*dx+dy*dy;
 return dist(p,lerp(a,b,den?clamp(((p[0]-a[0])*dx+(p[1]-a[1])*dy)/den,0,1):0));
}
function simplify(p,tol){
 const keep=new Set([0,p.length-1]), work=[[0,p.length-1]];
 while(work.length){const [a,b]=work.pop();let best=tol,split=-1;
   for(let i=a+1;i<b;i++){const error=pointSegment(p[i],p[a],p[b]);if(error>best){best=error;split=i}}
   if(split>=0){keep.add(split);work.push([a,split],[split,b]);}
 }
 return [...keep].sort((a,b)=>a-b);
}
// Chord-parametrized natural interpolating cubic. Both first and second
// derivatives match under the common chord parameter at every internal knot.
function natural(p){
 const n=p.length;if(n<2)return [];
 const h=p.slice(1).map((v,i)=>Math.max(1e-5,dist(v,p[i])));
 const lower=Array(n).fill(0),upper=Array(n).fill(0),diagonal=Array(n).fill(1);
 const rhs=p.map(()=>[0,0]);
 for(let i=1;i<n-1;i++){
   lower[i]=h[i-1];upper[i]=h[i];diagonal[i]=2*(h[i-1]+h[i]);
   for(let k=0;k<2;k++)rhs[i][k]=6*((p[i+1][k]-p[i][k])/h[i]-(p[i][k]-p[i-1][k])/h[i-1]);
 }
 for(let i=1;i<n;i++){const factor=lower[i]/diagonal[i-1];diagonal[i]-=factor*upper[i-1];
   for(let k=0;k<2;k++)rhs[i][k]-=factor*rhs[i-1][k];}
 const second=p.map(()=>[0,0]);
 for(let i=n-1;i>=0;i--)for(let k=0;k<2;k++)second[i][k]=(rhs[i][k]-(i<n-1?upper[i]*second[i+1][k]:0))/diagonal[i];
 return h.map((dt,i)=>{
   const c1=[],c2=[];
   for(let k=0;k<2;k++){
     const delta=(p[i+1][k]-p[i][k])/dt;
     c1[k]=p[i][k]+dt/3*(delta-dt*(2*second[i][k]+second[i+1][k])/6);
     c2[k]=p[i+1][k]-dt/3*(delta+dt*(second[i][k]+2*second[i+1][k])/6);
   }
   return [p[i],c1,c2,p[i+1]];
 });
}
function fit(points,smoothing=.7){
 const valid=[];for(const p of points||[])if(okay(p)&&(!valid.length||dist(p,valid[valid.length-1])>.1))valid.push(p.slice(0,2));
 if(valid.length<3)return natural(valid);
 const src=measurePoly(valid), level=clamp(number(smoothing,.7),0,1);
 const count=Math.max(2,Math.min(1200,Math.ceil(src.length/2)));
 const reach=level*5.5, even=[];
 for(let i=0;i<=count;i++){
   const s=i/count*src.length, window=Math.min(s,src.length-s,reach), p=src.at(s);
   const a=src.at(s-window),b=src.at(s+window),c=src.at(s-window*.52),d=src.at(s+window*.52);
   even.push([0,1].map(k=>(p[k]*4+a[k]+b[k]+2*(c[k]+d[k]))/10));
 }
 const tolerance=.48+level*2.45;
 const knots=simplify(even,tolerance);
 // A sparse polyline can meet the tolerance while a cubic through the same
 // knots overshoots. Refine the actual fitted curve against the filtered
 // samples, measuring by travelled distance within each knot interval.
 for(;;){
   const result=natural(knots.map(i=>even[i])),insert=[];
   for(let j=0;j<result.length;j++){
     const start=knots[j],end=knots[j+1];let worst=tolerance,split=-1;
     for(let i=start+1;i<end;i++){
       const error=dist(even[i],bez(result[j],(i-start)/(end-start)));
       if(error>worst){worst=error;split=i;}
     }
     if(split>=0)insert.push(split);
   }
   if(!insert.length)return result;
   knots.push(...insert);knots.sort((a,b)=>a-b);
 }
}
function bez(c,t){const a=lerp(c[0],c[1],t),b=lerp(c[1],c[2],t),d=lerp(c[2],c[3],t);return lerp(lerp(a,b,t),lerp(b,d,t),t);}
function tangent(c,t){const u=1-t;return norm(...[0,1].map(k=>u*u*(c[1][k]-c[0][k])+2*u*t*(c[2][k]-c[1][k])+t*t*(c[3][k]-c[2][k])));}
const arcCache=new WeakMap();
function arc(spine){
 if(arcCache.has(spine))return arcCache.get(spine);
 const records=[{s:0,i:0,u:0}];let l=0;
 for(let i=0;i<spine.length;i++){
   const c=spine[i],size=dist(c[0],c[1])+dist(c[1],c[2])+dist(c[2],c[3]), n=Math.max(7,Math.min(130,Math.ceil(size/1.3)));
   let last=c[0];
   for(let j=1;j<=n;j++){const u=j/n,p=bez(c,u);l+=dist(p,last);records.push({s:l,i,u});last=p;}
 }
 const result={length:l,records};arcCache.set(spine,result);return result;
}
function frame(spine,t){
 if(!spine?.length)return {p:[0,0],tangent:[1,0],normal:[0,1]};
 const {length,records}=arc(spine),s=clamp(t,0,1)*length;
 let a=0,b=records.length-1;while(b-a>1){const m=(a+b)>>1;if(records[m].s<s)a=m;else b=m;}
 const lo=records[a],hi=records[b],u=mix(lo.i===hi.i?lo.u:0,hi.u,(s-lo.s)/Math.max(1e-9,hi.s-lo.s));
 const tan=tangent(spine[hi.i],u);
 return {p:bez(spine[hi.i],u),tangent:tan,normal:[-tan[1],tan[0]]};
}
function widthAt(el,t){
 const entries=el.width?.length?el.width:[[0,4],[.5,9],[1,.8]];
 if(t<=entries[0][0])return Math.max(.04,entries[0][1]);
 for(let i=1;i<entries.length;i++)if(t<=entries[i][0])return Math.max(.04,mix(entries[i-1][1],entries[i][1],smooth((t-entries[i-1][0])/Math.max(.0001,entries[i][0]-entries[i-1][0]))));
 return Math.max(.04,entries[entries.length-1][1]);
}
function spiralFrame(f,angle,k,R,hand){
 // Integral of R exp(-k u) (cos u, sin u) du. Arc speed decays
 // exponentially and curvature increases from 1/R to exp(k u)/R.
 const e=Math.exp(-k*angle),c=Math.cos(angle),s=Math.sin(angle),den=1+k*k;
 const x=R*(k+e*(-k*c+s))/den;
 const y=hand*R*(1+e*(-k*s-c))/den;
 const tan=add([0,0],f.tangent,f.normal,c,hand*s);
 return {p:add(f.p,f.tangent,f.normal,x,y),tangent:tan,normal:[-tan[1],tan[0]]};
}
function curve(fn,a=0,b=1,steps=24){return Array.from({length:steps+1},(_,i)=>fn(mix(a,b,i/steps)));}
function path(points,first='M'){
 if(!points.length)return '';
 let s=first+xy(points[0]);
 // Cubic Hermite conversion through offset samples. Rounded joins are
 // native curves; cusp boundaries are separate subpaths joined deliberately.
 for(let i=1;i<points.length;i++){
   const a=points[i-1],b=points[i],pr=points[Math.max(0,i-2)],nx=points[Math.min(points.length-1,i+1)];
   s+='C'+xy([a[0]+(b[0]-pr[0])/6,a[1]+(b[1]-pr[1])/6])+' '+xy([b[0]-(nx[0]-a[0])/6,b[1]-(nx[1]-a[1])/6])+' '+xy(b);
 }
 return s;
}
const faceColors={outer:'#aa222a',inner:'#fff9e9',paper:'#fffdf7',ink:'#38292b'};
function outline(d,opts,back){
 const fill=opts.fill?(back?faceColors.inner:faceColors.outer):faceColors.paper;
 return '<path d="'+d+'" fill="'+fill+'" stroke="'+(opts.line?faceColors.ink:'none')+'" stroke-width=".78" stroke-linejoin="round"/>';
}
function ink(d,color,width,opacity=1){
 return '<path d="'+d+'" fill="none" stroke="'+color+'" stroke-width="'+fmt(width)+'" stroke-opacity="'+fmt(opacity)+'" stroke-linecap="round" stroke-linejoin="round"/>';
}
function volute(f,baseWidth,event,opt,back,ctx){
 const turns=clamp(number(event.turns,.88),.18,2.4), total=turns*TAU,hand=event.hand===-1?-1:1;
 const k=clamp(number(event.tightening,.25),.075,.68),R=clamp(number(event.radius,19),2,180);
 const eye=Math.max(.34,number(event.eye,1.65));
 function at(v){
   const a=v*total, localR=R*Math.exp(-k*a);
   const fr=spiralFrame(f,a,k,R,hand);
   // The outer shoulder gathers the major mass. As the sheet revolves, the
   // inside boundary retreats to expose a continuous strip of the lining.
   const cap=localR*(1-Math.exp(-k*TAU))*.83;
   const base=Math.min(baseWidth,R*.69);
   const taper=(1-smooth(v))*.28+.72*Math.pow(Math.max(0,1-v),.7);
   const spread=Math.min(cap,base*(1+.54*Math.sin(PI*Math.min(1,v*1.6)))*taper);
   const inner=Math.min(spread*(1-.29*smooth(v/.20)),Math.max(.04,localR-eye));
   return {fr,outer:Math.max(.015,spread),inner:Math.max(.015,inner)};
 }
 const coord=(v,u)=>{const {fr,outer,inner}=at(v); return add(fr.p,fr.tangent,fr.normal,0,hand*(u>0?u*inner:u*outer));};
 const n=Math.ceil(turns*44);
 const rootA=coord(0,-1), rootB=coord(0,1);
 const shape='M'+xy(add(rootA,f.tangent,f.normal,-.24,0))+path(curve(v=>coord(v,-1),0,1,n),'L')+path(curve(v=>coord(v,1),1,0,n),'L')+'L'+xy(add(rootB,f.tangent,f.normal,-.24,0))+'Z';
 let out=outline(shape,{...opt,line:false},back);
 if(opt.line)for(const side of [-1,1])out+=ink(path(curve(v=>coord(v,side),0,1,n)),faceColors.ink,.78);
 const wa=.15,wb=.94;
 function seam(v){const q=(v-wa)/(wb-wa);return 1-.83*Math.sin(PI*clamp(q,0,1))**.78;}
 const lining=path(curve(v=>coord(v,1),wa,wb,n))+path(curve(v=>coord(v,seam(v)),wb,wa,n),'L')+'Z';
 if(opt.fill||opt.shade||opt.line)out+=outline(lining,{...opt,line:false},!back);
 if(opt.shade){
   // Longitudinal bands follow the spiral. Their transverse values turn
   // from highlight to shadow in the same page-fixed light as the parent.
   for(const [edge,width] of [[-.77,.055],[-.35,.046],[-.02,.13],[.63,.05]]){
     for(let j=0;j<14;j++){
       const a=j/14,b=(j+1)/14,fr=at((a+b)/2).fr;
       const light=hand*(ctx.lightX*fr.normal[0]-.72*fr.normal[1]);
       const shade=edge===-.02?-.20:(edge*light>0?.27:-.14);
       const base=faceColor(opt,back);
       const band=closedBand(curve(v=>coord(v,edge-width),a,b,4),curve(v=>coord(v,edge+width),b,a,4));
       out+='<path d="'+band+'" fill="'+rgbShade(base,shade)+'" opacity=".66"/>';
     }
   }
 }
 if(opt.hatch){
   const length=R*(1-Math.exp(-k*total))/k;
   for(let s=1.3;s<length-.8;s+=2.9){
     const v=-Math.log(1-s*k/R)/(k*total),w=Math.min(.065,1.2/(R*Math.exp(-k*v*total)*total));
     const near=Math.min(1,v+w),end=Math.min(1,v+w*1.8);
     out+=ink('M'+xy(coord(v,-.94))+'Q'+xy(coord(near,-.57))+' '+xy(coord(end,-.32)),back||!opt.fill?'#746558':'#5e252b',.32,.73);
     if(Math.floor(s/2.9)%3===0)out+=ink('M'+xy(coord(v,-.49))+'Q'+xy(coord(near,-.78))+' '+xy(coord(end,-.9)),back||!opt.fill?'#746558':'#5e252b',.27,.58);
   }
 }
 if(opt.line)out+=ink(path(curve(v=>coord(v,seam(v)),wa,wb,n)),faceColors.ink,.51);
 if(opt.rib)out+=ink(path(curve(v=>coord(v,-.22+.16*Math.sin(PI*v)),0,.91,n)),back?'#7b645a':'#64202a',.52,.79);
 ctx.silhouettes.push(shape);
 return out;
}
function eye(spine,event){
 const f=frame(spine,number(event.t,1)), k=clamp(number(event.tightening,.25),.075,.68);
 const d=clamp(number(event.radius,19),2,180)/(1+k*k);
 return add(f.p,f.tangent,f.normal,k*d,(event.hand===-1?-1:1)*d);
}
// Every edit is stored in the element's authored coordinate system. Placement
// is a rigid transform. The parent's rotation propagates through descendants.
function placed(doc){
 const records=[];
 function visit(element,spine,back,rotation,attachment,parentId){
   if(!spine?.length)return;
   const rec={element,spine,back,rotation,attachment,parentId};
   records.push(rec);
   for(const e of element.events||[]){
     if(e.type!=='branch'||!e.child?.spine?.length)continue;
     const t=clamp(number(e.t,.5),0,1),f=frame(spine,t),base=e.child.spine[0][0];
     const offset=clamp(number(e.side,0),-1,1)*widthAt(element,t)*.52;
     const destination=add(f.p,f.tangent,f.normal,0,offset),childStart=frame(e.child.spine,0);
     let a=rotation;
     if(Number.isFinite(e.departure))a=Math.atan2(f.tangent[1],f.tangent[0])+
       e.departure*PI/180-Math.atan2(childStart.tangent[1],childStart.tangent[0]);
     const c=Math.cos(a),s=Math.sin(a),world=e.child.spine.map(segment=>segment.map(p=>{
       const x=p[0]-base[0],y=p[1]-base[1];return [destination[0]+c*x-s*y,destination[1]+s*x+c*y];
     }));
     const turns=(element.events||[]).filter(v=>v.type==='fold'&&number(v.t,.5)<=t).length;
     const inherited=back !== (turns%2===1);
     visit(e.child,world,inherited !== !!e.child.back,a,e,element.id);
   }
 }
 for(const e of doc.roots||[])visit(e,e.spine,!!e.back,0,null,null);
 return records;
}
function eventGeometry(el,spine){
 const L=arc(spine).length;
 const events=el.events||[];
 const folds=events.filter(e=>e.type==='fold').map(e=>({t:clamp(number(e.t,.5),.005,.995),length:clamp(number(e.length,.12),.018,.50),edge:e.edge===-1?-1:1})).sort((a,b)=>a.t-b.t);
 const clusters=[];
 // The union, including ranges on both edges, may occupy three fifths of
 // the strip. Overlapping lobes on the same edge share a single margin.
 const unionLength=ranges=>{
   const all=ranges.map(e=>[e.t0,e.t1]).sort((a,b)=>a[0]-b[0]);
   let end=0,sum=0;for(const [a,b] of all){sum+=Math.max(0,b-Math.max(a,end));end=Math.max(end,b);}return sum;
 };
 for(const e of events.filter(e=>e.type==='cluster')){
   let t0=clamp(number(e.t0,.4),0,1),t1=clamp(number(e.t1,.62),t0,1);
   const side=e.side===-1?-1:1;
   for(const old of clusters.filter(o=>o.side===side))if(t0<old.t1&&t1>old.t0){
     if(t0>=old.t0)t0=old.t1;else t1=old.t0;
   }
   if(t1<=t0)continue;
   if(unionLength([...clusters,{t0,t1}])>.600001){
     let a=t0,b=t1;for(let j=0;j<16;j++){const m=(a+b)/2;if(unionLength([...clusters,{t0,t1:m}])>.60)b=m;else a=m;}t1=a;
   }
   if((t1-t0)*L>1.4)clusters.push({...e,t0,t1,side});
 }
 return {folds,clusters,L};
}
function surface(el,spine,folds,t,q){
 t=clamp(t,0,1);
 const f=frame(spine,t),w=widthAt(el,t);
 let center=0,projection=1,skew=0;
 for(const fold of folds){
   const u=(t-fold.t)/fold.length+.5;
   if(u<=0||u>=1)continue;
   const wave=Math.sin(PI*u)**2;
   center+=fold.edge*.78*w*wave;
   projection*=1-.84*wave;
   skew+=fold.edge*w*.82*wave;
 }
 return add(f.p,f.tangent,f.normal,skew*q*(1-.20*q*q),center+w*q*projection);
}
function closedBand(a,b){
 return path(a)+path(b,'L')+'Z';
}
function rgbShade(base,intensity){
 const c=base.match(/\w\w/g).map(v=>parseInt(v,16));
 const target=intensity>0?[255,250,229]:[48,32,38],f=clamp(Math.abs(intensity),0,1);
 return '#'+c.map((v,i)=>Math.round(mix(v,target[i],f)).toString(16).padStart(2,'0')).join('');
}
function faceColor(opt,back){return opt.fill?(back?faceColors.inner:faceColors.outer):faceColors.paper}
function gradient(context,start,end,stops){
 const id=context.key();context.defs+='<linearGradient id="'+id+'" gradientUnits="userSpaceOnUse" x1="'+fmt(start[0])+'" y1="'+fmt(start[1])+'" x2="'+fmt(end[0])+'" y2="'+fmt(end[1])+'">'+stops.map(([u,c])=>'<stop offset="'+fmt(u)+'%" stop-color="'+c+'"/>').join('')+'</linearGradient>';
 return 'url(#'+id+')';
}
function crestLobes(el,spine,geo,cluster){
 const {t0,t1,side}=cluster,range=t1-t0,mid=(t0+t1)/2;
 const count=clamp(Math.round(number(cluster.splits,3)),2,4);
 const splits=Array.isArray(cluster.splits)?cluster.splits.slice(0,4):[.26,.43,.31,.21].slice(0,count);
 if(splits.length<2)splits.push(.38);
 const sum=splits.reduce((a,v)=>a+Math.max(.05,v),0),depth=clamp(Math.round(number(cluster.depth,1)),1,3);
 const maxHeight=widthAt(el,mid)*clamp(number(cluster.size,1.15),.22,3.7);
 const f0=frame(spine,mid),w=widthAt(el,mid),rootLength=range*geo.L;
 // Small tissue masses turn with their shared margin. When a narrow inner
 // bend cannot carry a full fan, reduce its extension before it can invert.
 const fa=frame(spine,Math.max(0,mid-.025)),fb=frame(spine,Math.min(1,mid+.025));
 const turn=Math.atan2(fa.tangent[0]*fb.tangent[1]-fa.tangent[1]*fb.tangent[0],fa.tangent[0]*fb.tangent[0]+fa.tangent[1]*fb.tangent[1]);
 const H=maxHeight/(1+Math.max(0,side*turn*w/Math.max(1,geo.L*.05)));
 function pt(u,h){
   const t=clamp(t0+range*u,0,1),f=frame(spine,t),p=surface(el,spine,geo.folds,t,side);
   return add(p,f.tangent,f.normal,0,side*h*H);
 }
 // Distal-pointing hooked tips are cubic pairs sharing their exact tip.
 // A subsidiary split lives on its parent's shoulder and has a shallower
 // sinus; only the principal sinuses reach the common base of the fan.
 const outlinePoints=[],ribs=[],leaves=[];
 function cubic(a,b,c,d,n=7){for(let i=1;i<=n;i++)outlinePoints.push(bez([a,b,c,d],i/n));}
 let cursor=0,last=pt(0,0);outlinePoints.push(last);
 function twig(a,b,base,tipH,level,major){
   const span=b-a;
   if(level>1){
     const divide=a+span*(.27+.07*Math.sin(major+level));
     twig(a,divide,base,tipH*.69,level-1,major+2);
     a=divide;
   }
   const h=tipH, length=b-a;
   // Hook the free end over an open sinus. The long outward bow gives the
   // tip room to reverse in height before it converges to a point.
   const pos=(x,y)=>pt(a+x*length,base+y*h);
   const shoulder=pos(.51,.91),tip=pos(1.22,.64);
   cubic(last,pos(-.08,.36),pos(-.07,.89),shoulder);
   cubic(shoulder,pos(.81,.97),pos(1.13,.82),tip);
   const deep=level===depth?.06:base+.23*h;
   const valley=pt(b-.15*length,deep);
   cubic(tip,pos(.89,.72),pos(.41,.62),valley);
   last=valley;
   const root=pt(Math.max(0,a-.22),-.34), veinTip=pos(1.03,.72);
   ribs.push([root,pt(a+.08*(b-a),-.2),pos(.12,.93),veinTip]);
   leaves.push({a:root,b:tip,axis:veinTip,span:Math.max(1,span*rootLength)});
 }
 for(let i=0;i<splits.length;i++){
   const next=cursor+Math.max(.05,splits[i])/sum;
   const shape=.65+.50*Math.sin(PI*((i+.50)/splits.length))+.17*Math.sin(i*2.13+rootLength*.07);
   twig(cursor,next,0,shape,depth,i);cursor=next;
 }
 const end=pt(1,0);
 cubic(last,pt(.972,.07),pt(.986,.016),end,4);
 // Carry each point's arclength fraction along this edge. With an intersecting
 // fold we clip the entire fan to its side of the projected turnover below.
 return {outline:outlinePoints,ribs,leaves,side,t0,t1,end,start:pt(0,0),p:pt};
}
function renderStrip(el,spine,back,opt,ctx){
 const geo=eventGeometry(el,spine),{L,folds}=geo;
 const lobes=geo.clusters.map(e=>crestLobes(el,spine,geo,e));
 const skin=(t,q)=>surface(el,spine,folds,t,q);
 function edge(a,b,side){
   const points=[];
   const selected=lobes.filter(e=>e.side===side&&e.t1>a&&e.t0<b).sort((x,y)=>x.t0-y.t0);
   let cursor=a;
   function addSegment(x,y){if(y<x)return;const count=Math.max(1,Math.ceil((y-x)*L/2.7));points.push(...curve(t=>skin(t,side),x,y,count));}
   for(const fan of selected){
     addSegment(cursor,Math.max(cursor,fan.t0));
     // The whole fan is divided in outline order if a fold crosses its range.
     const u=clamp((a-fan.t0)/(fan.t1-fan.t0),0,1),v=clamp((b-fan.t0)/(fan.t1-fan.t0),0,1);
     points.push(...fan.outline.slice(Math.floor(u*(fan.outline.length-1)),Math.ceil(v*(fan.outline.length-1))+1));
     cursor=Math.min(b,fan.t1);
   }
   addSegment(cursor,b);
   return points.filter((p,i)=>!i||dist(p,points[i-1])>.015);
 }
 function edgePath(points){return points.map((p,i)=>(i?'L':'M')+xy(p)).join('');}
 const limits=[0,...folds.map(v=>v.t),1];
 let out='';const faceAt=t=>back!==(folds.filter(e=>e.t<=t).length%2===1);
 for(let i=0;i<limits.length-1;i++){
   const a=limits[i],b=limits[i+1];if(b-a<1e-7)continue;
   const face=back!==(i%2===1), base=faceColor(opt,face),left=edge(a,b,-1),right=edge(a,b,1);
   if(!left.length||!right.length)continue;
   const fillShape=edgePath(left)+edgePath([...right].reverse()).replace(/^M/,'L')+'Z';
   ctx.silhouettes.push(fillShape);
   const clip=ctx.key();ctx.defs+='<clipPath id="'+clip+'"><path d="'+fillShape+'"/></clipPath>';
   let details='';
   out+='<path d="'+fillShape+'" fill="'+base+'"/>';
   if(opt.shade){
     // A transverse concave channel is sampled in a fixed world light. Its
     // shaded rim switches on bends and under bilateral reflection.
     const count=Math.max(2,Math.ceil((b-a)*L/3.7));
     for(let j=0;j<count;j++){
       const ta=mix(a,b,j/count),tb=mix(a,b,(j+1)/count),tm=(ta+tb)/2;
       const f=frame(spine,tm),w=widthAt(el,tm),light=ctx.lightX*f.normal[0]-.72*f.normal[1];
       const s0=skin(tm,-1),s1=skin(tm,1);
       const baseShade=(q)=>{
         const groove=.23*Math.exp(-Math.pow((q-.07)/.28,2)), rim=.25*Math.exp(-Math.pow((Math.abs(q)-.78)/.19,2));
         return -.02-groove+rim*.48+light*(-.47*q+.16*Math.sin(q*PI))+(face?.035:.005);
       };
       const stops=[-1,-.80,-.60,-.3,0,.22,.5,.78,1].map(q=>[(q+1)*50,rgbShade(base,baseShade(q))]);
       const fill=gradient(ctx,s0,s1,stops);
       const aa=Math.max(a,ta-.009/Math.max(1,L)),bb=Math.min(b,tb+.32/Math.max(1,L));
       const corners=[skin(aa,-1.01),skin(bb,-1.01),skin(bb,1.01),skin(aa,1.01)];
       details+='<path d="'+edgePath(corners)+'Z" fill="'+fill+'"/>';
     }
     for(const fan of lobes.filter(v=>v.t1>a&&v.t0<b)){
       // An asymmetric facet on each leaflet follows its own convex roll.
       for(let j=0;j<fan.leaves.length;j++){
         const leaf=fan.leaves[j],r=fan.ribs[j],w=Math.min(leaf.span*.2,widthAt(el,fan.t0)*.53);
         const axis=norm(leaf.b[0]-leaf.a[0],leaf.b[1]-leaf.a[1]),normal=[-axis[1],axis[0]];
         const start=r[0],tip=leaf.b,control=lerp(r[2],tip,.35),lit=ctx.lightX*normal[0]-.72*normal[1];
         const v=x=>add(control,axis,normal,0,w*x);
         const shape='M'+xy(start)+'Q'+xy(v(-.9))+' '+xy(tip)+'Q'+xy(v(.62))+' '+xy(start)+'Z';
         const fill=gradient(ctx,start,tip,[[0,rgbShade(base,-.31)],[48,rgbShade(base,.05)],[84,rgbShade(base,.13+Math.abs(lit)*.20)],[100,rgbShade(base,.04)]]);
         details+='<path d="'+shape+'" fill="'+fill+'"/>';
       }
     }
   }
   if(opt.hatch){
     const sgn=ctx.lightX*frame(spine,(a+b)/2).normal[0]-.72*frame(spine,(a+b)/2).normal[1]>0?1:-1;
     for(let t=a+.9/L;t<b;t+=2.65/L){
       const q=sgn*(.30+.18*Math.sin(t*9)),near=Math.min(b,t+1.7/L),far=Math.min(b,t+4.0/L);
       details+=ink('M'+xy(skin(t,sgn*.98))+'Q'+xy(skin(near,sgn*.64))+' '+xy(skin(far,q)),face||!opt.fill?'#65534c':'#552029',.38,.70);
       if(Math.floor(t*L/2.65)%3!==0)details+=ink('M'+xy(skin(t,sgn*.65))+'Q'+xy(skin(near,sgn*.72))+' '+xy(skin(far,sgn*.98)),face||!opt.fill?'#766358':'#57222a',.32,.56);
     }
     for(const fan of lobes.filter(v=>v.t1>a&&v.t0<b))for(const r of fan.ribs){
       for(let j=1;j<=4;j++){
         const u=.17+j*.12,p=bez(r,u),q=bez(r,Math.min(1,u+.11)),tan=tangent(r,u),n=[-tan[1],tan[0]];
         const end=add(q,tan,n,0,fan.side*(.6+widthAt(el,fan.t0)*.13));
         details+=ink('M'+xy(p)+'Q'+xy(q)+' '+xy(end),face||!opt.fill?'#65534c':'#552029',.33,.58);
       }
     }
   }
   if(opt.rib){
     const n=Math.max(4,Math.ceil((b-a)*L/4));
     const c=s=>skin(s,-.14+.12*Math.sin(PI*s));
     details+=ink(path(curve(c,a,b,n)),face||!opt.fill?'#806c5b':'#69232a',.56,.86);
     for(const fan of lobes.filter(v=>v.t1>a&&v.t0<b))for(const r of fan.ribs){
       details+=ink('M'+xy(r[0])+'C'+xy(r[1])+' '+xy(r[2])+' '+xy(r[3]),face||!opt.fill?'#786056':'#70222c',.45,.84);
     }
   }
   out+='<g clip-path="url(#'+clip+')">'+details+'</g>';
   if(opt.line){
     out+=ink(edgePath(left),faceColors.ink,.76)+ink(edgePath(right),faceColors.ink,.76);
     if(a===0)out+=ink('M'+xy(left[0])+'L'+xy(right[0]),faceColors.ink,.6);
     if(b===1&&!(el.events||[]).some(v=>v.type==='volute'&&v.t>=.999))out+=ink('M'+xy(left[left.length-1])+'L'+xy(right[right.length-1]),faceColors.ink,.61);
   }
 }
 for(const fold of folds){
   const t=fold.t,h=Math.min(fold.length*.54,1-t,t),s=fold.edge,old=!faceAt(t);
   if(!h)continue;
   const pt=(k,q)=>skin(t+k*h,s*q),start=pt(0,-.98),tip=pt(.96,.91);
   const lip='M'+xy(start)+'C'+xy(pt(-.22,-.18))+' '+xy(pt(.46,.37))+' '+xy(tip)+
     'C'+xy(pt(.66,.67))+' '+xy(pt(.25,.94))+' '+xy(pt(0,.98))+'Q'+xy(pt(.08,.11))+' '+xy(start)+'Z';
   let fill=faceColor(opt,old);
   if(opt.shade)fill=gradient(ctx,start,tip,[[0,rgbShade(fill,-.32)],[42,rgbShade(fill,.22)],[76,fill],[100,rgbShade(fill,-.12)]]);
   out+='<path d="'+lip+'" fill="'+fill+'" stroke="'+(opt.line?faceColors.ink:'none')+'" stroke-width=".58"/>';
 }
 for(const v of el.events||[])if(v.type==='volute'){
   const t=clamp(number(v.t,1),0,1);
   out+=volute(frame(spine,t),widthAt(el,t),v,opt,faceAt(t),ctx);
 }
 return out;
}
function render(doc,options={}){
 const opt={fill:true,line:true,rib:true,shade:false,hatch:false,...options};
 if(!(opt.fill||opt.line||opt.rib||opt.shade||opt.hatch))return '';
 let marks='',defs='',serial=0;
 const all=placed(doc), prefix=String(opt.idPrefix||'mantle2').replace(/[^a-zA-Z0-9_-]/g,'');
 for(const mirrored of doc.mirror?[false,true]:[false]){
   const ctx={defs:'',silhouettes:[],lightX:mirrored?.68:-.68,key:()=>prefix+'-'+(++serial)};
   const previous=[];
   function shadeOverlap(silhouettes){
     if(!opt.shade||!previous.length)return '';
     const clip=ctx.key();
     ctx.defs+='<clipPath id="'+clip+'">'+previous.map(id=>'<use href="#'+id+'" xlink:href="#'+id+'"/>').join('')+'</clipPath>';
     const dx=mirrored?-1.05:1.05;
     return '<g clip-path="url(#'+clip+')"><g transform="translate('+dx+' 1.6)" fill="#392827" stroke="#392827" stroke-width=".6" opacity=".25">'+
       silhouettes.map(d=>'<path d="'+d+'"/>').join('')+'</g></g>';
   }
   function paint(rec){
     const kids=all.filter(p=>p.parentId===rec.element.id);
     const behind=kids.filter(p=>p.attachment.order!=='front').map(paint).join('');
     ctx.silhouettes=[];
     const strip=renderStrip(rec.element,rec.spine,rec.back,opt,ctx);
     const shade=shadeOverlap(ctx.silhouettes);
     if(opt.shade){
       const id=ctx.key();ctx.defs+='<path id="'+id+'" d="'+ctx.silhouettes.join(' ')+'"/>';previous.push(id);
     }
     const front=kids.filter(p=>p.attachment.order==='front').map(paint).join('');
     return behind+shade+strip+front;
   }
   let half=all.filter(p=>p.parentId===null).map(paint).join('');
   if(opt.shade&&opt.helm!==false&&previous.length){
     const helm='M182 107 Q186 98 197 97 Q211 95 218 102 Q224 108 220 119 L217 129 Q213 141 220 149 L225 154 Q212 153 198 162 L191 167 Q184 163 184 156 Q187 148 184 140 L179 134 Q170 129 170 122 Q169 114 182 107Z';
     // The helmet itself is asymmetric and lives in unreflected world space.
     const edge=mirrored?'M218 107 Q214 98 203 97 Q189 95 182 102 Q176 108 180 119 L183 129 Q187 141 180 149 L175 154 Q188 153 202 162 L209 167 Q216 163 216 156 Q213 148 216 140 L221 134 Q230 129 230 122 Q231 114 218 107Z':helm;
     half+=shadeOverlap([edge]);
   }
   marks+=mirrored?'<g transform="translate(400 0) scale(-1 1)">'+half+'</g>':half;
   defs+=ctx.defs;
 }
 return '<g xmlns:xlink="http://www.w3.org/1999/xlink"><defs>'+defs+'</defs>'+marks+'</g>';
}
return {fit,frame,widthAt,eye,placed,render};
});
