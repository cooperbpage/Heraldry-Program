(() => {
  const $=id=>document.getElementById(id), sheet=$('plate');
  const state=()=>JSON.parse(localStorage.getItem('mantling-event-studies-2'));
  const assert=(v,m)=>{if(!v)throw Error(m);};
  const tool=name=>document.querySelector('[data-tool="'+name+'"]').click();
  // Programmatically dispatched pointer events have no native pointer capture.
  sheet.setPointerCapture=()=>{};
  function draw(points){
    points.forEach(([x,y],i)=>{
      const p=new DOMPoint(x,y).matrixTransform(sheet.getScreenCTM());
      sheet.dispatchEvent(new PointerEvent(i===0?'pointerdown':i===points.length-1?'pointerup':'pointermove',{pointerId:7,button:0,buttons:i===points.length-1?0:1,clientX:p.x,clientY:p.y,bubbles:true}));
    });
  }
  function changed(id,val){$(id).value=val;$(id).dispatchEvent(new Event('change'));}
  if(document.querySelector('[data-opt=hatch]').checked)document.querySelector('[data-opt=hatch]').click();
  if($('generative').checked)$('generative').click();
  $('reset').click();assert(!state().doc.roots.length,'reset');
  $('smoothing').value=.9;$('smoothing').dispatchEvent(new Event('input'));
  draw([[210,120],[230,120],[270,120],[300,120],[330,120]]);
  assert(state().doc.roots.length===1,'sweep');
  tool('cluster');draw([[228,123],[242,123],[255,123]]);
  tool('fold');draw([[272,117],[278,120],[287,123]]);
  tool('volute');draw([[305,120],[310,130],[315,140]]);
  tool('branch');draw([[260,120],[263,130],[270,143],[275,151]]);
  const events=state().doc.roots[0].events;
  for(const type of ['cluster','fold','volute','branch'])assert(events.some(e=>e.type===type),type);
  tool('width');draw([[285,120],[285,128],[285,139]]);
  assert(state().doc.roots[0].width.some(w=>w[1]>16),'width edit');
  for(const [kind,id,y] of [['pointerdown',1,117],['pointerdown',2,123],['pointermove',1,97],['pointermove',2,143],['pointerup',2,143],['pointerup',1,97]]){
    const p=new DOMPoint(310,y).matrixTransform(sheet.getScreenCTM());
    sheet.dispatchEvent(new PointerEvent(kind,{pointerId:id,button:0,clientX:p.x,clientY:p.y,bubbles:true}));
  }
  assert(state().doc.roots[0].width.some(w=>Math.abs(w[1]-23)<1),'two-finger width');
  const before=JSON.stringify(state().doc);
  document.querySelector('[data-opt=hatch]').click();$('undo').click();
  assert(state().settings.hatch&&state().settings.smoothing===.9,'settings survived undo');
  $('redo').click();assert(JSON.stringify(state().doc)===before,'redo');
  $('reset').click();$('generative').click();tool('sweep');
  draw([[210,120],[237,117],[268,133],[300,147]]);
  const a=state().doc.roots[0];assert(a.events.length>=3,'compose');
  $('reseed').click();const b=state().doc.roots[0];
  assert(JSON.stringify(a.spine)===JSON.stringify(b.spine)&&JSON.stringify(a.events)!==JSON.stringify(b.events),'reseed');
  tool('cluster');changed('target',b.id);changed('event',b.events.find(e=>e.type==='cluster').id);
  const size=document.querySelector('[aria-label=Size]');size.value=2.3;size.dispatchEvent(new Event('change'));$('reseed').click();
  assert(state().doc.roots[0].events.some(e=>!e.generated&&e.size===2.3),'retain edited generated event');
  for(const key of ['stirling','stag','parchment','tassels','lion']){changed('presets',key);assert(state().doc.preset===key&&$('art').childElementCount>0,key);}
  return 'PASS: reset, sweep, bracket, fork, width, volute, fold, settings-independent undo/redo, compose, reseed, retained manual edit, five presets';
})()
