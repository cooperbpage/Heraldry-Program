'use strict';
const fs=require('fs'),G=require('../geometry.js');
const el={id:'isolated-volute',spine:G.fit([[84,191],[115,174],[140,146],[180,119]]),width:[[0,3],[1,12.5]],events:[{type:'volute',t:1,turns:1.06,radius:37,hand:1,tightening:.23,eye:3.1}]};
const image=G.render({roots:[el],mirror:false},{fill:true,line:true,rib:true});
const svg='<svg xmlns="http://www.w3.org/2000/svg" width="720" height="540" viewBox="70 73 190 143"><rect x="0" y="0" width="400" height="370" fill="#faf7ee"/>'+image+'</svg>';
fs.writeFileSync(__dirname+'/01-volute.svg',svg);
