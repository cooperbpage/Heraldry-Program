"""Build the self-contained phone edition. No server-side runtime is required."""
from pathlib import Path
from base64 import b64encode
root = Path(__file__).resolve().parent
html = (root / 'page.html').read_text()
for face in ('roman','italic'):
    font = root / (face+'.woff')
    if not font.exists():
        font = root.parent / font.name
    html = html.replace('{{'+face.upper()+'}}', b64encode(font.read_bytes()).decode())
for key, file in [('GEOMETRY','geometry.js'),('MODEL','model.js'),('HELM','helmet.svg'),('PRESETS','presets.json'),('APP','app.js')]:
    html = html.replace('{{'+key+'}}',(root / file).read_text())
out = root.parent / 'dist' if (root.parent / '.openai').exists() else root / 'dist'
out.mkdir(exist_ok=True)
(out/'index.html').write_text(html)
