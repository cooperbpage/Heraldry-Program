export type Point = [number, number];
export type Cubic = [Point, Point, Point, Point];
export type Spine = Cubic[];
export type Side = -1 | 1;
interface Mark { id?: string; generated?: boolean }
export interface Cluster extends Mark { type: 'cluster'; t0: number; t1: number; side: Side; size: number; depth: number; splits?: number[] | number }
export interface Fold extends Mark { type: 'fold'; t: number; length: number; edge: Side }
export interface Volute extends Mark { type: 'volute'; t: number; radius: number; turns: number; hand: Side; tightening: number }
export interface Branch extends Mark { type: 'branch'; t: number; side?: Side; departure?: number; child: Strip; order?: 'front' | 'behind' }
export interface Strip { id: string; spine: Spine; width: [number,number][]; events: (Cluster | Fold | Volute | Branch)[] }
export interface Design { mirror: boolean; roots: Strip[]; preset?: string }
export interface Layers { fill?: boolean; line?: boolean; rib?: boolean; shade?: boolean; hatch?: boolean }
export interface Frame { p: Point; tangent: Point; normal: Point; curvature?: number }
export function fit(points: Point[], smoothing?: number): Spine;
export function interpolate(points: Point[]): Spine;
export function frame(spine: Spine, station: number): Frame;
export function widthAt(strip: Strip, station: number): number;
export function eye(spine: Spine, event: Volute): Point;
export function render(design: Design, layers?: Layers): string;
