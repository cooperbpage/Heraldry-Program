'use strict';
(() => {
  const $ = selector => document.querySelector(selector);
  const all = selector => [...document.querySelectorAll(selector)];
  const clone = value => JSON.parse(JSON.stringify(value));
  const historic = (s, italic=false) => (italic ? s.replace(/ss/g,'ß') : s).replace(/s(?=[a-zA-Zſß])/g,'ſ');
  const walker = document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);
  while(walker.nextNode()){
    const n=walker.currentNode;
    if(!n.parentElement.closest('script,style')) n.textContent=historic(n.textContent,!!n.parentElement.closest('i'));
  }
  const plate=$('#plate'), overlay=$('#overlay'), presets=Studies.presets;
  const initial={strokes:clone(presets.canopy),preset:'canopy',method:'acanthus',fill:true,line:true,rib:true,shade:false,hatch:false,width:1,detail:1};
  const key='mantling-studio-1';
  let state=clone(initial), tool='draw', active=null, before=[], after=[], guides=false;
  try{const saved=JSON.parse(localStorage.getItem(key));if(saved && Array.isArray(saved.strokes)&&saved.method)state={...initial,...saved};}catch{}
  function checkpoint(){before.push(clone(state));if(before.length>40)before.shift();after=[];}
  const help={draw:'Draw on either side. Begin on an existing stem to branch, or at its tip to extend.',twist:'Tap a stem to turn the cloth at that point. Tap the same mark to undo the turn.',curl:'Tap near a tip to cycle through an inward curl, an outward curl and a plain ending.',erase:'Tap a stem to remove it and its reflection.'};
  const say = s => {$('#hint').textContent=historic(s);};
  const dist=(a,b)=>Math.hypot(a[0]-b[0],a[1]-b[1]);
  function hit(p,tips=false){
    let best=null;
    state.strokes.forEach((s,i)=>{
      const pts=Mantling.sample(s.points);
      for(let j=tips?pts.length-1:0;j<pts.length;j++){
        const d=dist(pts[j],p);
        if(!best||d<best.d)best={i,p:pts[j],t:j/Math.max(1,pts.length-1),d};
      }
    });return best;
  }
  const coords=ev=>{const m=plate.getScreenCTM();const p=new DOMPoint(ev.clientX,ev.clientY).matrixTransform(m.inverse());return [Math.min(397,200+Math.abs(p.x-200)),Math.max(3,Math.min(367,p.y))];};
  const pointsPath=pts=>pts.map((p,i)=>(i?'L':'M')+p.map(v=>v.toFixed(1)).join(' ')).join('');
  function drawOverlay(){
    let markup='';
    if(guides || tool==='twist' || tool==='curl' || tool==='erase'){
      state.strokes.forEach(s=>{
        const pts=Mantling.sample(s.points);
        markup+='<path d="'+pointsPath(pts)+'" fill="none" stroke="#92705e" stroke-width=".65" stroke-dasharray="2 2"/>';
        for(const t of s.twists||[]){const p=pts[Math.round(t*(pts.length-1))];markup+='<circle cx="'+p[0]+'" cy="'+p[1]+'" r="2.6" fill="#fffdf7" stroke="#8a3334"/>';}
        if(tool==='curl'){const p=pts.at(-1);markup+='<circle cx="'+p[0]+'" cy="'+p[1]+'" r="4" fill="white" stroke="#8a3334"/>';}
      });
    }
    if(active&&tool==='draw')markup+='<path d="'+pointsPath(active.pts)+'" fill="none" stroke="#93383e" stroke-width="1.6" stroke-dasharray="3 2"/>';
    overlay.innerHTML=markup?'<g>'+markup+'</g><g transform="translate(400 0) scale(-1 1)">'+markup+'</g>':'';
  }
  function render(){
    $('#art').innerHTML=Mantling.render(state.strokes,state);
    $('#arms').innerHTML=Studies.helmet;
    all('[data-layer]').forEach(e=>e.checked=state[e.dataset.layer]);
    all('[data-method]').forEach(e=>e.setAttribute('aria-pressed',String(e.dataset.method===state.method)));
    all('[data-tool]').forEach(e=>e.setAttribute('aria-pressed',String(e.dataset.tool===tool)));
    $('#width').value=state.width;$('#detail').value=state.detail;$('#preset').value=state.preset;
    $('#undo').disabled=!before.length;$('#redo').disabled=!after.length;drawOverlay();
    try{localStorage.setItem(key,JSON.stringify(state));}catch{}
  }
  function editAt(p){
    const near=hit(p,tool==='curl');
    if(!near||near.d>(tool==='curl'?34:20)){say('Tap closer to a marked tip or stem.');return;}
    checkpoint();const s=state.strokes[near.i];
    if(tool==='erase')state.strokes.splice(near.i,1);
    if(tool==='twist'){s.twists??=[];const index=s.twists.findIndex(v=>Math.abs(v-near.t)<.065);if(index>=0)s.twists.splice(index,1);else s.twists.push(Math.max(.05,Math.min(.95,near.t)));s.twists.sort((a,b)=>a-b);}
    if(tool==='curl'){const v=s.curl??.5;s.curl=v>0?-.9:v<0?0:.9;}
    state.preset='custom';render();say(help[tool]);
  }
  plate.addEventListener('pointerdown',ev=>{
    if(active||ev.button!==0)return;
    ev.preventDefault();const p=coords(ev);plate.setPointerCapture(ev.pointerId);
    const near=hit(p);
    active={id:ev.pointerId,pts:[tool==='draw'&&near&&near.d<13?near.p:p],start:p,near};
    drawOverlay();
  });
  plate.addEventListener('pointermove',ev=>{
    if(!active||ev.pointerId!==active.id||tool!=='draw')return;
    for(const e of (ev.getCoalescedEvents?.().length?ev.getCoalescedEvents():[ev])){
      const p=coords(e);if(dist(active.pts.at(-1),p)>2)active.pts.push(p);
    }drawOverlay();
  });
  plate.addEventListener('pointerup',ev=>{
    if(!active||active.id!==ev.pointerId)return;
    const g=active;active=null;const end=coords(ev);
    if(tool!=='draw'){editAt(end);return;}
    if(dist(end,g.pts.at(-1))>2)g.pts.push(end);
    const len=g.pts.slice(1).reduce((n,p,i)=>n+dist(p,g.pts[i]),0);
    if(len<8){drawOverlay();return;}
    checkpoint();
    const n=g.near;
    if(n&&n.d<13&&n.t>.94){
      const s=state.strokes[n.i], orig=Mantling.sample(s.points);
      const base=orig.slice(1).reduce((v,p,i)=>v+dist(p,orig[i]),0);
      s.twists=(s.twists||[]).map(t=>t*base/(base+len));s.points.push(...g.pts.slice(1));
    }else{
      const parent=n&&n.d<13?state.strokes[n.i]:null;
      state.strokes.push({points:g.pts,twists:len>70?[.52]:[],scale:parent?Math.max(.5,(parent.scale||1)*.76):1,curl:.55});
    }
    state.preset='custom';render();
  });
  function cancel(){active=null;drawOverlay();}
  plate.addEventListener('pointercancel',cancel);plate.addEventListener('lostpointercapture',()=>{if(active)cancel();});
  all('[data-method]').forEach(e=>e.onclick=()=>{checkpoint();state.method=e.dataset.method;render();});
  all('[data-tool]').forEach(e=>e.onclick=()=>{tool=e.dataset.tool;say(help[tool]);render();});
  all('[data-layer]').forEach(e=>e.onchange=()=>{checkpoint();state[e.dataset.layer]=e.checked;render();});
  for(const id of ['width','detail']){const e=$('#'+id);e.onchange=()=>{checkpoint();state[id]=+e.value;render();};}
  $('#guides').onchange=e=>{guides=e.target.checked;drawOverlay();};
  $('#preset').onchange=e=>{checkpoint();state.preset=e.target.value;state.strokes=clone(presets[state.preset]||[]);render();};
  $('#undo').onclick=()=>{if(before.length){after.push(clone(state));state=before.pop();render();}};
  $('#redo').onclick=()=>{if(after.length){before.push(clone(state));state=after.pop();render();}};
  $('#export').onclick=()=>{
    const svg='<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="800" height="740" viewBox="0 0 400 370">'+$('#art').innerHTML+Studies.helmet+'</svg>';
    const url=URL.createObjectURL(new Blob([svg],{type:'image/svg+xml'}));const a=document.createElement('a');
    a.href=url;a.download='Mantling.svg';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);
  };
  render();say(help[tool]);
})();
