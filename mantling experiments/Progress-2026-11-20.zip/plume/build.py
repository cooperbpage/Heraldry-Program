from pathlib import Path
from base64 import b64encode
root = Path(__file__).resolve().parent
html = (root / 'page.html').read_text()
for face in ('roman','italic'):
    html = html.replace('{{'+face.upper()+'}}', b64encode((root / (face+'.woff')).read_bytes()).decode())
for key, file in [('ENGINE','engine.js'),('STUDIES','studies.js'),('APP','app.js')]:
    html = html.replace('{{'+key+'}}',(root / file).read_text())
(root/'dist').mkdir(exist_ok=True)
(root/'dist/index.html').write_text(html)
