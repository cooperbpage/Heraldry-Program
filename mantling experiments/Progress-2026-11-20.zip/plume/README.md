# Studies in Mantling

Open the private web edition on a phone, or open Mantling.html in a browser that runs local HTML and JavaScript. The offline page embeds both fonts and every drawing routine. Changes to the study are saved in the browser's local storage where available. Export SVG produces artwork; the browser retains the editable drawing separately.

## Drawing

Choose a composition from the top-right menu. Choose Blank sheet to start at the helm. Draw on either side. Start close to the interior of an existing guide to attach a narrower branch, or at its endpoint to extend the guide. A stroke begun away from the others remains independent. Later strokes paint above earlier ones; the helmet and shield paint last.

Twist adds or removes a face reversal at the tapped position. Curl tip cycles a marked guide endpoint through the two curl directions and a plain ending. Erase removes an entire paired stroke. Use Guides to see the editable paths, Undo to recover a drawing after clearing or changing the composition, and Redo to restore the last undone change. Width and Detail apply to the whole drawing. Change Method to compare constructions on precisely the same gestures.

The five finish switches operate independently. For line drawing, turn off Flat colour and leave Outline and Midrib on. For an unoutlined flat silhouette, leave only Flat colour on. Shading and Hatching can be used separately or together. The shield and visor serve as fixed registration drawings throughout.

## Reusing the generator

engine.js has no DOM, framework, network, or font dependencies. Use CommonJS in Node or load it as a classic script to obtain window.Mantling. The matching engine.d.ts describes its interface for TypeScript. The renderer returns SVG inner markup for a 400 by 370 viewBox, including both mirrored halves and any necessary definitions. The application draws the shield and helm separately.

```js
const stroke = {
  points: [[202,104], [234,110], [268,96], [292,72], [310,76]],
  twists: [0.45], curl: -0.8, scale: 1, back: false
};
const markup = Mantling.render([stroke], {
  method: 'acanthus', fill: true, line: true, rib: true,
  shade: false, hatch: true, idPrefix: 'achievement1'
});
```

Store the strokes and options with each achievement so the design stays editable. Place the resulting SVG beneath the helmet; supply a unique idPrefix for each achievement shown on the same page. The illustrated branches are ornamental constructions. Freehand branches snap geometrically when drawn; this prototype stores independent strokes, so deleting a parent can leave an offshoot in place.

## Files and reproduction

- engine.js and engine.d.ts — drawing library and TypeScript declaration
- studies.js — guide coordinates for the three specimens and the original helmet and shield drawing
- page.html and app.js — page template and gesture controller
- roman.woff and italic.woff — interface glyph subsets from the supplied Garamond Premier Pro X Medium Caption and Medium Italic Caption faces; OpenType substitutions are retained
- build.py — run with Python 3 to generate dist/index.html. Its contents are identical to the delivered Mantling.html.
- render-comparison.js — run with Node to generate a comparison SVG; rasterize with Inkscape to reproduce the PNG
- research.md — historical sources, visual analysis and notes on the geometric methods
